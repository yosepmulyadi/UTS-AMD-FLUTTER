import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // layoutjoinnowpH6 (19:2)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfffaf8ee),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // topappbarx8Q (188:96)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
              padding: EdgeInsets.fromLTRB(16*fem, 20*fem, 16*fem, 20*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // autogroupwkmjrUg (XVEodXS9vCHg8PjRRzWKmJ)
                    margin: EdgeInsets.fromLTRB(0.67*fem, 0*fem, 0*fem, 16*fem),
                    width: 342.33*fem,
                    height: 24*fem,
                    child: Align(
                      // backyJQ (I188:96;124:727)
                      alignment: Alignment.centerLeft,
                      child: SizedBox(
                        width: 25*fem,
                        height: 24*fem,
                        child: Image.asset(
                          'assets/page-1/images/back-Vkc.png',
                          width: 25*fem,
                          height: 24*fem,
                        ),
                      ),
                    ),
                  ),
                  Text(
                    // headline7ov (I188:96;124:690)
                    'Sign Up',
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 24*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.3333333333*ffem/fem,
                      color: Color(0xff001e2f),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupdcyxrFi (XVEkuwJ51zJ7ZHG8nXdCYx)
              margin: EdgeInsets.fromLTRB(20*fem, 0*fem, 17*fem, 0*fem),
              width: double.infinity,
              height: 1026*fem,
              child: Stack(
                children: [
                  Positioned(
                    // line1PFe (60:259)
                    left: 91*fem,
                    top: 681*fem,
                    child: Align(
                      child: SizedBox(
                        width: 151*fem,
                        height: 5*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group218JNc (220:203)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      width: 338*fem,
                      height: 1026*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffffffff),
                        borderRadius: BorderRadius.circular(10*fem),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x3f000000),
                            offset: Offset(0*fem, 4*fem),
                            blurRadius: 2*fem,
                          ),
                        ],
                      ),
                      child: Stack(
                        children: [
                          Positioned(
                            // line2LaC (121:108)
                            left: 29*fem,
                            top: 105.5202636719*fem,
                            child: Align(
                              child: SizedBox(
                                width: 248*fem,
                                height: 1*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line3rHe (121:109)
                            left: 29*fem,
                            top: 180.6416015625*fem,
                            child: Align(
                              child: SizedBox(
                                width: 248*fem,
                                height: 1*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line4BKv (121:110)
                            left: 29*fem,
                            top: 252.7977294922*fem,
                            child: Align(
                              child: SizedBox(
                                width: 248*fem,
                                height: 1*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line5uFv (121:111)
                            left: 29*fem,
                            top: 322.9768066406*fem,
                            child: Align(
                              child: SizedBox(
                                width: 248*fem,
                                height: 1*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line6E3J (121:112)
                            left: 29*fem,
                            top: 395.1329345703*fem,
                            child: Align(
                              child: SizedBox(
                                width: 248*fem,
                                height: 1*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line7wTW (121:113)
                            left: 29*fem,
                            top: 466.3005371094*fem,
                            child: Align(
                              child: SizedBox(
                                width: 248*fem,
                                height: 1*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line8f8c (121:114)
                            left: 27*fem,
                            top: 605.9133300781*fem,
                            child: Align(
                              child: SizedBox(
                                width: 248*fem,
                                height: 1*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // line9C8Y (121:115)
                            left: 29*fem,
                            top: 673.1271972656*fem,
                            child: Align(
                              child: SizedBox(
                                width: 248*fem,
                                height: 1*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // firstname8H6 (119:96)
                            left: 28*fem,
                            top: 120.3468017578*fem,
                            child: Align(
                              child: SizedBox(
                                width: 113*fem,
                                height: 25*fem,
                                child: Text(
                                  'First Name*',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 20*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff605656),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // pleaseinputyourpersonaldetailb (120:104)
                            left: 24*fem,
                            top: 14.572265625*fem,
                            child: Align(
                              child: SizedBox(
                                width: 240*fem,
                                height: 19*fem,
                                child: Text(
                                  'Please input your personal detail',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 15*ffem,
                                    fontWeight: FontWeight.w700,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff605656),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // pleaseinputyouraccountpersonal (121:106)
                            left: 20.5*fem,
                            top: 501.0693359375*fem,
                            child: Align(
                              child: SizedBox(
                                width: 303*fem,
                                height: 19*fem,
                                child: Text(
                                  'Please input your account personal detail',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 15*ffem,
                                    fontWeight: FontWeight.w700,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff605656),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // autogroupcwi4B8t (XVEmNvX6xfdHo3XqtpcWi4)
                            left: 44*fem,
                            top: 801.6242675781*fem,
                            child: Container(
                              width: 274.5*fem,
                              height: 14.83*fem,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    // autogroupjcwctoz (XVEmYLR62X9RqhMDDJjcWC)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7.5*fem, 0*fem),
                                    width: 15*fem,
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      border: Border.all(color: Color(0xff000000)),
                                      color: Color(0x99ffffff),
                                    ),
                                    child: Center(
                                      // rectangle33QnL (121:130)
                                      child: SizedBox(
                                        width: double.infinity,
                                        height: 14.83*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            border: Border.all(color: Color(0xff000000)),
                                            color: Color(0x99ffffff),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  RichText(
                                    // iagreetotheacctermofserviceand (121:131)
                                    textAlign: TextAlign.center,
                                    text: TextSpan(
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 10*ffem,
                                        fontWeight: FontWeight.w700,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xff605656),
                                      ),
                                      children: [
                                        TextSpan(
                                          text: 'I agree to the ACC',
                                        ),
                                        TextSpan(
                                          text: ' term of service ',
                                          style: SafeGoogleFont (
                                            'Inter',
                                            fontSize: 10*ffem,
                                            fontWeight: FontWeight.w700,
                                            height: 1.2125*ffem/fem,
                                            color: Color(0xff5a57e8),
                                          ),
                                        ),
                                        TextSpan(
                                          text: 'and ',
                                        ),
                                        TextSpan(
                                          text: 'privacy police',
                                          style: SafeGoogleFont (
                                            'Inter',
                                            fontSize: 10*ffem,
                                            fontWeight: FontWeight.w700,
                                            height: 1.2125*ffem/fem,
                                            color: Color(0xff5a57e8),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Positioned(
                            // lastnameABA (119:97)
                            left: 27.5*fem,
                            top: 194.4797363281*fem,
                            child: Align(
                              child: SizedBox(
                                width: 112*fem,
                                height: 25*fem,
                                child: Text(
                                  'Last Name*',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 20*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff605656),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // dateofbirth3Vr (119:98)
                            left: 27*fem,
                            top: 268.6127929688*fem,
                            child: Align(
                              child: SizedBox(
                                width: 130*fem,
                                height: 25*fem,
                                child: Text(
                                  'Date of birth*',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 20*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff605656),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // yeargraduateLE4 (120:99)
                            left: 27.5*fem,
                            top: 408.9710693359*fem,
                            child: Align(
                              child: SizedBox(
                                width: 146*fem,
                                height: 25*fem,
                                child: Text(
                                  'Year Graduate*',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 20*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff605656),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // universitynameDHr (120:105)
                            left: 26.5*fem,
                            top: 335.8266601562*fem,
                            child: Align(
                              child: SizedBox(
                                width: 166*fem,
                                height: 25*fem,
                                child: Text(
                                  'University Name*',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 20*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff605656),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // phonenumberVWG (120:100)
                            left: 29*fem,
                            top: 49.1791992188*fem,
                            child: Align(
                              child: SizedBox(
                                width: 151*fem,
                                height: 25*fem,
                                child: Text(
                                  'Phone Number*',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 20*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff605656),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // emailaXi (120:101)
                            left: 27*fem,
                            top: 543.6416015625*fem,
                            child: Align(
                              child: SizedBox(
                                width: 61*fem,
                                height: 25*fem,
                                child: Text(
                                  'Email*',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 20*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff605656),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // passwordfp4 (120:102)
                            left: 27*fem,
                            top: 618.7629394531*fem,
                            child: Align(
                              child: SizedBox(
                                width: 103*fem,
                                height: 25*fem,
                                child: Text(
                                  'Password*',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 20*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff605656),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // confirmpasswordZuS (120:103)
                            left: 25*fem,
                            top: 690.9189453125*fem,
                            child: Align(
                              child: SizedBox(
                                width: 183*fem,
                                height: 25*fem,
                                child: Text(
                                  'Confirm Password*',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 20*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff605656),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // required576 (121:128)
                            left: 23.5*fem,
                            top: 771.9711914062*fem,
                            child: Align(
                              child: SizedBox(
                                width: 71*fem,
                                height: 19*fem,
                                child: Text(
                                  'Required*',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 15*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff605656),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // autogrouptjapn1W (XVEmffYCzuHW42XvTBtjap)
                            left: 28*fem,
                            top: 941.9826660156*fem,
                            child: Container(
                              width: 281*fem,
                              height: 58.32*fem,
                              decoration: BoxDecoration (
                                color: Color(0xff496454),
                              ),
                              child: Center(
                                child: Text(
                                  'Sign Up',
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 25*ffem,
                                    fontWeight: FontWeight.w700,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // viewf5J (197:295)
                            left: 248.1422119141*fem,
                            top: 729.75*fem,
                            child: Align(
                              child: SizedBox(
                                width: 24.85*fem,
                                height: 15.5*fem,
                                child: Image.asset(
                                  'assets/page-1/images/view-qJg.png',
                                  width: 24.85*fem,
                                  height: 15.5*fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // viewmPE (220:200)
                            left: 248.1422119141*fem,
                            top: 649.75*fem,
                            child: Align(
                              child: SizedBox(
                                width: 24.85*fem,
                                height: 15.5*fem,
                                child: Image.asset(
                                  'assets/page-1/images/view-qua.png',
                                  width: 24.85*fem,
                                  height: 15.5*fem,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}