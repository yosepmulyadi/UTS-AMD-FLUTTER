import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // layoutinfoagendaTck (165:9)
        width: double.infinity,
        height: 812*fem,
        decoration: BoxDecoration (
          color: Color(0xfffaf8ee),
        ),
        child: Stack(
          children: [
            Positioned(
              // rectangle38aSU (165:10)
              left: 0*fem,
              top: 129*fem,
              child: Align(
                child: SizedBox(
                  width: 375*fem,
                  height: 32*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // autogroupxe1wtTA (XVF2mEPJ2gTT5uKaruxE1W)
              left: 0*fem,
              top: 166*fem,
              child: Container(
                width: 375*fem,
                height: 70*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // rectangle271Gt (166:131)
                      left: 0*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 375*fem,
                          height: 70*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              boxShadow: [
                                BoxShadow(
                                  color: Color(0x3f000000),
                                  offset: Offset(0*fem, 4*fem),
                                  blurRadius: 2*fem,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // digitalindustrygatewayknowandp (166:130)
                      left: 9*fem,
                      top: 11*fem,
                      child: Align(
                        child: SizedBox(
                          width: 322*fem,
                          height: 16*fem,
                          child: Text(
                            'DIGITAL INDUSTRY GATEWAY: KNOW AND PREPARE',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 13*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // screenshot20230314at07001LiU (166:132)
                      left: 0*fem,
                      top: 29*fem,
                      child: Align(
                        child: SizedBox(
                          width: 375*fem,
                          height: 36*fem,
                          child: Image.asset(
                            'assets/page-1/images/screen-shot-2023-03-14-at-0700-1.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group217EYx (246:709)
              left: 0*fem,
              top: 732*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(37.5*fem, 13*fem, 33*fem, 12*fem),
                width: 375*fem,
                height: 80*fem,
                decoration: BoxDecoration (
                  color: Color(0xfff3f4f9),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // autogroupdtvnXHA (XVF3Jt9Ds4ErYnXZfgDtVN)
                      margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 53*fem, 0*fem),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // icon42C (246:712)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                            width: 24*fem,
                            height: 24*fem,
                            child: Image.asset(
                              'assets/page-1/images/icon-rv4.png',
                              width: 24*fem,
                              height: 24*fem,
                            ),
                          ),
                          Text(
                            // labeltextNHn (246:713)
                            'Home',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.3333333333*ffem/fem,
                              letterSpacing: 0.5*fem,
                              color: Color(0xff001c38),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroupups85hz (XVF3UNsQDNNgBrHkuhuPS8)
                      margin: EdgeInsets.fromLTRB(0*fem, 5.55*fem, 37.5*fem, 0*fem),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // searchp9n (246:718)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 14.55*fem),
                            width: 18.9*fem,
                            height: 18.9*fem,
                            child: Image.asset(
                              'assets/page-1/images/search-iaC.png',
                              width: 18.9*fem,
                              height: 18.9*fem,
                            ),
                          ),
                          Text(
                            // labeltext8AU (246:715)
                            'Search',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.3333333333*ffem/fem,
                              letterSpacing: 0.5*fem,
                              color: Color(0xff001c38),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroupt6bsTCk (XVF3csdFAB8Jhxi35Ct6bS)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 32*fem, 0*fem),
                      width: 64*fem,
                      height: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupwqs2b44 (XVF3ksPvQEBqfbTMhSWQs2)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7*fem),
                            padding: EdgeInsets.fromLTRB(20*fem, 3*fem, 20*fem, 5*fem),
                            width: double.infinity,
                            decoration: BoxDecoration (
                              image: DecorationImage (
                                fit: BoxFit.cover,
                                image: AssetImage (
                                  'assets/page-1/images/active-indicator-vTa.png',
                                ),
                              ),
                            ),
                            child: Center(
                              // megaphoneUNk (246:719)
                              child: SizedBox(
                                width: 24*fem,
                                height: 24*fem,
                                child: Image.asset(
                                  'assets/page-1/images/megaphone-Hax.png',
                                  width: 24*fem,
                                  height: 24*fem,
                                ),
                              ),
                            ),
                          ),
                          Container(
                            // labeltext17n (246:716)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                            child: Text(
                              'Announ',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 12*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.3333333333*ffem/fem,
                                letterSpacing: 0.5*fem,
                                color: Color(0xff001c38),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroupovau7gc (XVF3u7fBVf6RQU3A6JovaU)
                      margin: EdgeInsets.fromLTRB(0*fem, 6*fem, 0*fem, 0*fem),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // settingsFnp (246:711)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.51*fem, 13*fem),
                            width: 19.49*fem,
                            height: 20*fem,
                            child: Image.asset(
                              'assets/page-1/images/settings-3D2.png',
                              width: 19.49*fem,
                              height: 20*fem,
                            ),
                          ),
                          Text(
                            // labeltextyD2 (246:717)
                            'Setting',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.3333333333*ffem/fem,
                              letterSpacing: 0.5*fem,
                              color: Color(0xff001c38),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // rectangle1374L (165:26)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 375*fem,
                  height: 129*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff496454),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // yosepmulyadiZS8 (165:38)
              left: 64*fem,
              top: 77*fem,
              child: Align(
                child: SizedBox(
                  width: 83*fem,
                  height: 15*fem,
                  child: Text(
                    'Yosep Mulyadi',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // universitasipendidikanindonesi (165:39)
              left: 63*fem,
              top: 99*fem,
              child: Align(
                child: SizedBox(
                  width: 159*fem,
                  height: 13*fem,
                  child: Text(
                    'Universitasi Pendidikan Indonesia',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 10*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line5Mct (165:40)
              left: 64*fem,
              top: 96*fem,
              child: Align(
                child: SizedBox(
                  width: 155*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse9FTN (165:41)
              left: 327*fem,
              top: 80*fem,
              child: Align(
                child: SizedBox(
                  width: 30*fem,
                  height: 30*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(15*fem),
                      color: Color(0xfffaf8ee),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // bellaEk (191:271)
              left: 333*fem,
              top: 87*fem,
              child: Align(
                child: SizedBox(
                  width: 18*fem,
                  height: 18*fem,
                  child: Image.asset(
                    'assets/page-1/images/bell-iXr.png',
                    width: 18*fem,
                    height: 18*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse10V6p (165:42)
              left: 7*fem,
              top: 69*fem,
              child: Align(
                child: SizedBox(
                  width: 49*fem,
                  height: 49*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(24.5*fem),
                      color: Color(0xfffaf8ee),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // avaremovebgpreview1BkL (165:44)
              left: 9*fem,
              top: 71*fem,
              child: Align(
                child: SizedBox(
                  width: 45*fem,
                  height: 45*fem,
                  child: Image.asset(
                    'assets/page-1/images/ava-removebg-preview-1-dVa.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle35JKA (165:46)
              left: 0*fem,
              top: 129*fem,
              child: Align(
                child: SizedBox(
                  width: 375*fem,
                  height: 32*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // pengumumanReg (165:47)
              left: 18.5*fem,
              top: 134*fem,
              child: Align(
                child: SizedBox(
                  width: 130*fem,
                  height: 25*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Text(
                      'Pengumuman',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2125*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // agendaKk4 (165:48)
              left: 180.5*fem,
              top: 134*fem,
              child: Align(
                child: SizedBox(
                  width: 73*fem,
                  height: 25*fem,
                  child: Text(
                    'Agenda',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // berita6uE (165:49)
              left: 289*fem,
              top: 134*fem,
              child: Align(
                child: SizedBox(
                  width: 56*fem,
                  height: 25*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Text(
                      'Berita',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2125*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}