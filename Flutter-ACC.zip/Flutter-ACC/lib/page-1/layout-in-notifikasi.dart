import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // layoutinnotifikasizBJ (224:421)
        width: double.infinity,
        height: 812*fem,
        decoration: BoxDecoration (
          color: Color(0xfffaf8ee),
        ),
        child: Stack(
          children: [
            Positioned(
              // autogroupvj8c82c (XVEqFK5DSu2LDG7nvfVj8C)
              left: 0*fem,
              top: 0*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(12*fem, 30*fem, 155*fem, 15*fem),
                width: 375*fem,
                height: 77*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x3f000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 2*fem,
                    ),
                  ],
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // image7y3E (228:682)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 115.5*fem, 0*fem),
                      width: 25.5*fem,
                      height: 24*fem,
                      child: Image.asset(
                        'assets/page-1/images/image-7.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                    Text(
                      // headline67r (228:683)
                      'Pesan',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 24*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.3333333333*ffem/fem,
                        color: Color(0xff001e2f),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // autogroupcpysDCU (XVEqTZDpAMTgRx5FdecPyS)
              left: 0*fem,
              top: 78*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(36*fem, 210*fem, 36*fem, 315*fem),
                width: 375*fem,
                height: 734*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x3f000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 2*fem,
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // vectorGgY (225:475)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 44*fem),
                      width: 51*fem,
                      height: 55*fem,
                      child: Image.asset(
                        'assets/page-1/images/vector.png',
                        width: 51*fem,
                        height: 55*fem,
                      ),
                    ),
                    Container(
                      // selamatdatangdiaccbTv (224:436)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 9*fem),
                      child: Text(
                        'Selamat datang di ACC!',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Inter',
                          fontSize: 20*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.2125*ffem/fem,
                          color: Color(0xff000000),
                        ),
                      ),
                    ),
                    Container(
                      // kamutelahberhasilmendahtarkanp (224:437)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
                      constraints: BoxConstraints (
                        maxWidth: 303*fem,
                      ),
                      child: Text(
                        'Kamu telah berhasil mendahtarkan profil di Alumni Career Center. Lanjutkan pencarian pekerjaan di ACC sekarang!',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Inter',
                          fontSize: 15*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.2125*ffem/fem,
                          color: Color(0xff8b8b8b),
                        ),
                      ),
                    ),
                    Text(
                      // maret20231212xSt (224:438)
                      '04 Maret 2023, 12.12',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 13*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2125*ffem/fem,
                        color: Color(0xff8b8b8b),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // deletetrL (224:472)
              left: 338*fem,
              top: 34*fem,
              child: Align(
                child: SizedBox(
                  width: 24*fem,
                  height: 24*fem,
                  child: Image.asset(
                    'assets/page-1/images/delete.png',
                    width: 24*fem,
                    height: 24*fem,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}