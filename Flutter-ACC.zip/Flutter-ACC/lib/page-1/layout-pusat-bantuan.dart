import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // layoutpusatbantuanTnG (228:702)
        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 282*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfffaf8ee),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupuh6yiTJ (XVFNnQXV7yDBdSUVqQUH6Y)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
              width: double.infinity,
              height: 231*fem,
              child: Stack(
                children: [
                  Positioned(
                    // rectangle775x4 (228:703)
                    left: 0*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 375*fem,
                        height: 77*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xffffffff),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x3f000000),
                                offset: Offset(0*fem, 4*fem),
                                blurRadius: 2*fem,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // image7iVW (228:704)
                    left: 12*fem,
                    top: 34*fem,
                    child: Align(
                      child: SizedBox(
                        width: 25.5*fem,
                        height: 24*fem,
                        child: Image.asset(
                          'assets/page-1/images/image-7-H36.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // headlinetHW (228:705)
                    left: 113*fem,
                    top: 30*fem,
                    child: Align(
                      child: SizedBox(
                        width: 158*fem,
                        height: 32*fem,
                        child: Text(
                          'Pusat Bantuan',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 24*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.3333333333*ffem/fem,
                            color: Color(0xff001e2f),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle27oHz (228:706)
                    left: 0*fem,
                    top: 61*fem,
                    child: Align(
                      child: SizedBox(
                        width: 375*fem,
                        height: 170*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xff496454),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x3f000000),
                                offset: Offset(0*fem, 4*fem),
                                blurRadius: 2*fem,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // apayangbisakamibantuHcU (228:714)
                    left: 12.5*fem,
                    top: 124*fem,
                    child: Align(
                      child: SizedBox(
                        width: 279*fem,
                        height: 27*fem,
                        child: Text(
                          'Apa yang bisa kami bantu?',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 22*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2125*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // haloyosepCsr (228:715)
                    left: 18*fem,
                    top: 93*fem,
                    child: Align(
                      child: SizedBox(
                        width: 107*fem,
                        height: 22*fem,
                        child: Text(
                          'Halo YOSEP,',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 18*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2125*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // masukanpertanyaankamuBUt (228:718)
                    left: 47*fem,
                    top: 175*fem,
                    child: Align(
                      child: SizedBox(
                        width: 229*fem,
                        height: 22*fem,
                        child: Text(
                          'Masukan pertanyaan kamu',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 18*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2125*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // searchyvY (228:716)
                    left: 16.5498046875*fem,
                    top: 177.5498046875*fem,
                    child: Align(
                      child: SizedBox(
                        width: 18.9*fem,
                        height: 18.9*fem,
                        child: Image.asset(
                          'assets/page-1/images/search-iUY.png',
                          width: 18.9*fem,
                          height: 18.9*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // line309yS (228:719)
                    left: 20*fem,
                    top: 213*fem,
                    child: Align(
                      child: SizedBox(
                        width: 334*fem,
                        height: 1*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // rectangle78mE8 (228:707)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
              width: double.infinity,
              height: 70*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
            ),
            Container(
              // rectangle79n9E (228:708)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
              width: double.infinity,
              height: 70*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
            ),
            Container(
              // rectangle80pbi (228:709)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
              width: double.infinity,
              height: 70*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
            ),
            Container(
              // rectangle81fMS (228:710)
              width: double.infinity,
              height: 70*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}