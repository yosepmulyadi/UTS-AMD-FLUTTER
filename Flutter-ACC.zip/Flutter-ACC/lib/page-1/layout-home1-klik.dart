import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // layouthome1klikKXv (224:342)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfffaf8ee),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // topappbarFRa (224:388)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
              padding: EdgeInsets.fromLTRB(16*fem, 20*fem, 16*fem, 20*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // autogrouptiqg8VN (XVEtqNmCKBqaLZRo1rtiQg)
                    margin: EdgeInsets.fromLTRB(0.67*fem, 0*fem, 0*fem, 16*fem),
                    width: 342.33*fem,
                    height: 24*fem,
                    child: Align(
                      // backTGk (I224:388;124:727)
                      alignment: Alignment.centerLeft,
                      child: SizedBox(
                        width: 25*fem,
                        height: 24*fem,
                        child: Image.asset(
                          'assets/page-1/images/back.png',
                          width: 25*fem,
                          height: 24*fem,
                        ),
                      ),
                    ),
                  ),
                  Text(
                    // headlinea6U (I224:388;124:690)
                    'Detail Perusahaan',
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 24*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.3333333333*ffem/fem,
                      color: Color(0xff001e2f),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // rectangle27u8k (225:476)
              width: double.infinity,
              height: 699*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}