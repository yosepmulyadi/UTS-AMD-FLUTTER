import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // layoutinfopengumumanQEk (155:2)
        width: double.infinity,
        height: 812*fem,
        decoration: BoxDecoration (
          color: Color(0xfffaf8ee),
        ),
        child: Stack(
          children: [
            Positioned(
              // autogroupx6cpEDn (XVF132mFeeMEKF9bHLx6Cp)
              left: 0*fem,
              top: 0*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(0*fem, 129*fem, 0*fem, 237*fem),
                width: 375*fem,
                height: 732*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // rectangle38Km2 (159:2)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 0*fem),
                      width: double.infinity,
                      height: 32*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffffffff),
                      ),
                    ),
                    Container(
                      // autogroupggcxFPn (XVEz5E2uXC9rndozknggcx)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 2*fem),
                      width: double.infinity,
                      height: 193*fem,
                      child: Stack(
                        children: [
                          Positioned(
                            // line27yag (165:4)
                            left: 21*fem,
                            top: 3*fem,
                            child: Align(
                              child: SizedBox(
                                width: 128*fem,
                                height: 3*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xff496454),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // rectangle27gzt (166:113)
                            left: 0*fem,
                            top: 54*fem,
                            child: Align(
                              child: SizedBox(
                                width: 375*fem,
                                height: 139*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3f000000),
                                        offset: Offset(0*fem, 4*fem),
                                        blurRadius: 2*fem,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // ythalumnistmikakakomditemp3tuk (166:115)
                            left: 35.5*fem,
                            top: 110*fem,
                            child: Align(
                              child: SizedBox(
                                width: 304*fem,
                                height: 64*fem,
                                child: Text(
                                  'Yth. Alumni STMIK AKAKOM di Temp3tuk lulusan Tahun 2019 dan Tahun 2020, baik yang SUDAH BEKERJA/BELUM BEKERJA/WIRASWASTA/STUDI LANJUT dimohon kesediaannya mengisi...',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 13*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff8b8b8b),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // informasitracerstudyuntuktahun (166:120)
                            left: 12.5*fem,
                            top: 65*fem,
                            child: Align(
                              child: SizedBox(
                                width: 348*fem,
                                height: 39*fem,
                                child: Text(
                                  'INFORMASI TRACER STUDY UNTUK TAHUN 2019 DAN TAHUN 2020',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // textfieldsearchT1z (228:752)
                            left: 9*fem,
                            top: 0*fem,
                            child: Container(
                              width: 358*fem,
                              height: 70*fem,
                              decoration: BoxDecoration (
                                borderRadius: BorderRadius.circular(8*fem),
                              ),
                              child: Container(
                                // autogroupnvaqAh6 (XVEzP8gjXrRdMQ3eEmnVaQ)
                                width: double.infinity,
                                height: 50*fem,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      // bgWW4 (I228:752;13:9701)
                                      left: 0*fem,
                                      top: 10*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 358*fem,
                                          height: 40*fem,
                                          child: Container(
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(8*fem),
                                              color: Color(0x7fe0e0e0),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // textfieldPZr (I228:752;13:9951)
                                      left: 0*fem,
                                      top: 10*fem,
                                      child: Container(
                                        padding: EdgeInsets.fromLTRB(12*fem, 8*fem, 12*fem, 8*fem),
                                        width: 49*fem,
                                        height: 40*fem,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(8*fem),
                                        ),
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // captionszp (I228:752;13:9959)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                              child: Text(
                                                'PT',
                                                style: SafeGoogleFont (
                                                  'IBM Plex Sans',
                                                  fontSize: 16*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.5*ffem/fem,
                                                  letterSpacing: 0.2687999916*fem,
                                                  color: Color(0xff818181),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              // caretteZck (I228:752;13:10108)
                                              width: 3*fem,
                                              height: 24*fem,
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(1*fem),
                                                color: Color(0xff1572ec),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // iconsr78U (I228:752;13:9715)
                                      left: 322*fem,
                                      top: 18*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 24*fem,
                                          height: 24*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/icons-r.png',
                                            width: 24*fem,
                                            height: 24*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroup1qkzCQp (XVEzrTEYcNDXxp6f3F1QKz)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 0*fem),
                      padding: EdgeInsets.fromLTRB(39.5*fem, 14*fem, 33.5*fem, 2*fem),
                      width: double.infinity,
                      decoration: BoxDecoration (
                        color: Color(0xffffffff),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x3f000000),
                            offset: Offset(0*fem, 4*fem),
                            blurRadius: 2*fem,
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // pengisianformkuisioneralumnisW (166:126)
                            margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 8*fem),
                            child: Text(
                              'PENGISIAN FORM KUISIONER ALUMNI',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 16*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.2125*ffem/fem,
                                color: Color(0xff000000),
                              ),
                            ),
                          ),
                          Container(
                            // selamatsiangtemantemanalumnisa (166:128)
                            constraints: BoxConstraints (
                              maxWidth: 302*fem,
                            ),
                            child: Text(
                              'Selamat siang teman teman alumniSalam sehat selalu Dalam rangka perubahan bentuk dari STMIK Akakom ke Universitas Teknologi Digital Indonesia, kami dari bagian ACC STMIK AKAKOM mohon untuk dapat meluangkan waktunya sejenak...',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 13*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.2125*ffem/fem,
                                color: Color(0xff8b8b8b),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group217nXS (216:532)
              left: 0*fem,
              top: 732*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(37.5*fem, 13*fem, 33*fem, 12*fem),
                width: 375*fem,
                height: 80*fem,
                decoration: BoxDecoration (
                  color: Color(0xfff3f4f9),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // autogroupqletsYt (XVF1vqcGA51qN37XVnQLet)
                      margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 53*fem, 0*fem),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // icon1QC (216:536)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                            width: 24*fem,
                            height: 24*fem,
                            child: Image.asset(
                              'assets/page-1/images/icon-Rv8.png',
                              width: 24*fem,
                              height: 24*fem,
                            ),
                          ),
                          Text(
                            // labeltext8Up (216:537)
                            'Home',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.3333333333*ffem/fem,
                              letterSpacing: 0.5*fem,
                              color: Color(0xff001c38),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogrouprfx4TX6 (XVF23Am3iwmiTQxKf8rfx4)
                      margin: EdgeInsets.fromLTRB(0*fem, 5.55*fem, 37.5*fem, 0*fem),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // searchPvY (216:542)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 14.55*fem),
                            width: 18.9*fem,
                            height: 18.9*fem,
                            child: Image.asset(
                              'assets/page-1/images/search-JhN.png',
                              width: 18.9*fem,
                              height: 18.9*fem,
                            ),
                          ),
                          Text(
                            // labeltextutt (216:539)
                            'Search',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.3333333333*ffem/fem,
                              letterSpacing: 0.5*fem,
                              color: Color(0xff001c38),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroupx1w8EwA (XVF295krsXTBaj4zCmX1W8)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 32*fem, 0*fem),
                      width: 64*fem,
                      height: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroup2xrnMVz (XVF2E5cXu4N9BVnZbR2xRN)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7*fem),
                            padding: EdgeInsets.fromLTRB(20*fem, 3*fem, 20*fem, 5*fem),
                            width: double.infinity,
                            decoration: BoxDecoration (
                              image: DecorationImage (
                                fit: BoxFit.cover,
                                image: AssetImage (
                                  'assets/page-1/images/active-indicator-GGY.png',
                                ),
                              ),
                            ),
                            child: Center(
                              // megaphoneFbN (246:692)
                              child: SizedBox(
                                width: 24*fem,
                                height: 24*fem,
                                child: Image.asset(
                                  'assets/page-1/images/megaphone.png',
                                  width: 24*fem,
                                  height: 24*fem,
                                ),
                              ),
                            ),
                          ),
                          Container(
                            // labeltextyGU (216:540)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                            child: Text(
                              'Announ',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 12*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.3333333333*ffem/fem,
                                letterSpacing: 0.5*fem,
                                color: Color(0xff001c38),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogrouplu5igRn (XVF2KVdBLtMWkLEGbnLu5i)
                      margin: EdgeInsets.fromLTRB(0*fem, 6*fem, 0*fem, 0*fem),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // settingsd68 (216:534)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.51*fem, 13*fem),
                            width: 19.49*fem,
                            height: 20*fem,
                            child: Image.asset(
                              'assets/page-1/images/settings-z32.png',
                              width: 19.49*fem,
                              height: 20*fem,
                            ),
                          ),
                          Text(
                            // labeltextLWL (216:541)
                            'Setting',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.3333333333*ffem/fem,
                              letterSpacing: 0.5*fem,
                              color: Color(0xff001c38),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // rectangle13foW (155:33)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 375*fem,
                  height: 129*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff496454),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // yosepmulyadiMRS (155:45)
              left: 64*fem,
              top: 77*fem,
              child: Align(
                child: SizedBox(
                  width: 83*fem,
                  height: 15*fem,
                  child: Text(
                    'Yosep Mulyadi',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // universitasipendidikanindonesi (155:46)
              left: 63*fem,
              top: 99*fem,
              child: Align(
                child: SizedBox(
                  width: 159*fem,
                  height: 13*fem,
                  child: Text(
                    'Universitasi Pendidikan Indonesia',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 10*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line5kCg (155:47)
              left: 64*fem,
              top: 96*fem,
              child: Align(
                child: SizedBox(
                  width: 155*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse9SLQ (155:48)
              left: 327*fem,
              top: 80*fem,
              child: Align(
                child: SizedBox(
                  width: 30*fem,
                  height: 30*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(15*fem),
                      color: Color(0xfffaf8ee),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse10kbz (155:49)
              left: 7*fem,
              top: 69*fem,
              child: Align(
                child: SizedBox(
                  width: 49*fem,
                  height: 49*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(24.5*fem),
                      color: Color(0xfffaf8ee),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // bell4sa (191:274)
              left: 333*fem,
              top: 87*fem,
              child: Align(
                child: SizedBox(
                  width: 18*fem,
                  height: 18*fem,
                  child: Image.asset(
                    'assets/page-1/images/bell-YJL.png',
                    width: 18*fem,
                    height: 18*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // avaremovebgpreview1nYg (155:51)
              left: 9*fem,
              top: 71*fem,
              child: Align(
                child: SizedBox(
                  width: 45*fem,
                  height: 45*fem,
                  child: Image.asset(
                    'assets/page-1/images/ava-removebg-preview-1-LYg.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle35utC (155:60)
              left: 0*fem,
              top: 129*fem,
              child: Align(
                child: SizedBox(
                  width: 375*fem,
                  height: 32*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // pengumumanRrY (165:3)
              left: 18.5*fem,
              top: 134*fem,
              child: Align(
                child: SizedBox(
                  width: 130*fem,
                  height: 25*fem,
                  child: Text(
                    'Pengumuman',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // agendavoJ (165:5)
              left: 180.5*fem,
              top: 134*fem,
              child: Align(
                child: SizedBox(
                  width: 73*fem,
                  height: 25*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Text(
                      'Agenda',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2125*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // beritaD1i (165:6)
              left: 289*fem,
              top: 134*fem,
              child: Align(
                child: SizedBox(
                  width: 56*fem,
                  height: 25*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Text(
                      'Berita',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2125*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}