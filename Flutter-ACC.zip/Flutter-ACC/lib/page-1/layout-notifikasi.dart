import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // layoutnotifikasiT1i (110:69)
        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 498*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfffaf8ee),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // topappbarZ4k (188:154)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 20*fem),
              padding: EdgeInsets.fromLTRB(16*fem, 20*fem, 16*fem, 20*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // autogroup6qqcFyA (XVEpkKuWhCvmjbAFfK6qQC)
                    margin: EdgeInsets.fromLTRB(0.67*fem, 0*fem, 0*fem, 16*fem),
                    width: 342.33*fem,
                    height: 24*fem,
                    child: Align(
                      // backPJg (I188:154;124:727)
                      alignment: Alignment.centerLeft,
                      child: SizedBox(
                        width: 25*fem,
                        height: 24*fem,
                        child: Image.asset(
                          'assets/page-1/images/back-D9a.png',
                          width: 25*fem,
                          height: 24*fem,
                        ),
                      ),
                    ),
                  ),
                  Text(
                    // headlineVMi (I188:154;124:690)
                    'Pesan',
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 24*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.3333333333*ffem/fem,
                      color: Color(0xff001e2f),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroup8p5nchE (XVEp8qvdoiqxyiUGPX8p5n)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
              width: double.infinity,
              height: 37*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  'Notifikasi',
                  textAlign: TextAlign.center,
                  style: SafeGoogleFont (
                    'Inter',
                    fontSize: 25*ffem,
                    fontWeight: FontWeight.w400,
                    height: 1.2125*ffem/fem,
                    color: Color(0xff000000),
                  ),
                ),
              ),
            ),
            Container(
              // autogroup7xf6rrU (XVEpHLgUkXbbVptYZ27XF6)
              padding: EdgeInsets.fromLTRB(41*fem, 8*fem, 29*fem, 14*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // selamatdatangdiaccXxc (129:69)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 80*fem, 7*fem),
                    child: Text(
                      'Selamat datang di ACC!',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2125*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                  Container(
                    // kamutelahberhasilmendahtarkanp (129:71)
                    margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 11*fem),
                    constraints: BoxConstraints (
                      maxWidth: 303*fem,
                    ),
                    child: Text(
                      'Kamu telah berhasil mendahtarkan profil di Alumni Career Center. Lanjutkan pencarian pekerjaan di ACC sekarang!',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 15*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2125*ffem/fem,
                        color: Color(0xff8b8b8b),
                      ),
                    ),
                  ),
                  Container(
                    // maret202312126eL (129:72)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 152*fem, 0*fem),
                    child: Text(
                      '04 Maret 2023, 12.12',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 15*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2125*ffem/fem,
                        color: Color(0xff8b8b8b),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}