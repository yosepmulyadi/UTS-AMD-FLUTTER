import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // layoutkonfirmasiKHr (60:215)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
          image: DecorationImage (
            fit: BoxFit.cover,
            image: AssetImage (
              'assets/page-1/images/layout-awal-1-bg-VMS.png',
            ),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // rectangle24d3e (60:232)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 29*fem),
              width: double.infinity,
              height: 140*fem,
              decoration: BoxDecoration (
                color: Color(0xfffaf8ee),
              ),
            ),
            Container(
              // selamatbergabungkPA (60:229)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 212*fem),
              child: Text(
                'Selamat Bergabung!!!',
                textAlign: TextAlign.center,
                style: SafeGoogleFont (
                  'Marvel',
                  fontSize: 20*ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.21*ffem/fem,
                  color: Color(0xff000000),
                ),
              ),
            ),
            Container(
              // autogroup16auS16 (XVEjnPLxgr7scNKsFK16aU)
              margin: EdgeInsets.fromLTRB(23*fem, 0*fem, 31*fem, 99*fem),
              width: double.infinity,
              height: 97*fem,
              child: Stack(
                children: [
                  Positioned(
                    // rectangle22MNx (60:230)
                    left: 0*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 321*fem,
                        height: 78*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xfffaf8ee),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // alumnicareercenterberkomitmenu (60:228)
                    left: 23.5*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 282*fem,
                        height: 97*fem,
                        child: Text(
                          'Alumni Career Center berkomitmen untuk sebaik mungkin melakukan layanan karir untuk mahasiswa dan lulusan sesuai target mutu',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Marvel',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.21*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupbozgXAx (XVEjvTwqDMo6AR21o6Bozg)
              width: double.infinity,
              height: 210*fem,
              child: Stack(
                children: [
                  Positioned(
                    // rectangle23sVi (60:231)
                    left: 0*fem,
                    top: 20*fem,
                    child: Align(
                      child: SizedBox(
                        width: 375*fem,
                        height: 190*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xfffaf8ee),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // line1zKS (60:263)
                    left: 111*fem,
                    top: 196*fem,
                    child: Align(
                      child: SizedBox(
                        width: 151*fem,
                        height: 5*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // fabWHn (188:394)
                    left: 147*fem,
                    top: 0*fem,
                    child: Container(
                      width: 86*fem,
                      height: 40*fem,
                      decoration: BoxDecoration (
                        color: Color(0xff2f4156),
                        borderRadius: BorderRadius.circular(100*fem),
                      ),
                      child: Center(
                        child: Center(
                          child: Text(
                            'Agree',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.4285714286*ffem/fem,
                              letterSpacing: 0.1000000015*fem,
                              color: Color(0xffd7e2ff),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}