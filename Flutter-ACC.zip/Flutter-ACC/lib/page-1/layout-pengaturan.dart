import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // layoutpengaturantzk (225:1753)
        width: double.infinity,
        height: 812*fem,
        decoration: BoxDecoration (
          color: Color(0xfffaf8ee),
        ),
        child: Stack(
          children: [
            Positioned(
              // group9pNc (225:1754)
              left: 19*fem,
              top: 146*fem,
              child: Container(
                width: 338*fem,
                height: 374*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // autogroupgaygL64 (XVEvzypaFBb158uoAPGaYg)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(10*fem, 21*fem, 5*fem, 21*fem),
                        width: 338*fem,
                        height: 323*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.circular(10*fem),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Container(
                              // autogroupxd5rzRW (XVEwGyMvjHi4zQQSQrXD5r)
                              margin: EdgeInsets.fromLTRB(33.5*fem, 0*fem, 0*fem, 15*fem),
                              width: double.infinity,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    // profilsayavKA (225:1756)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 169.5*fem, 0*fem),
                                    child: Text(
                                      'Profil Saya',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 20*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // rightarrow1p9e (225:1762)
                                    margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                                    width: 20*fem,
                                    height: 20*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/right-arrow-1.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // line67eY (225:1767)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9*fem, 17*fem),
                              width: 279*fem,
                              height: 1*fem,
                              decoration: BoxDecoration (
                                color: Color(0xffb7b7b7),
                              ),
                            ),
                            Container(
                              // autogroupxwakePa (XVEwSDbXEDzqrEL9tFXWak)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 19*fem),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // vectorA72 (225:1824)
                                    margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 8.5*fem, 0*fem),
                                    width: 24*fem,
                                    height: 24*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/vector-NKa.png',
                                      width: 24*fem,
                                      height: 24*fem,
                                    ),
                                  ),
                                  Container(
                                    // keamanaakunUNc (225:1757)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 128.5*fem, 2*fem),
                                    child: Text(
                                      'Keamana Akun',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 20*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // rightarrow2awS (225:1763)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                                    width: 20*fem,
                                    height: 20*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/right-arrow-2.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // line7KPE (225:1768)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 17*fem),
                              width: 279*fem,
                              height: 1*fem,
                              decoration: BoxDecoration (
                                color: Color(0xffb7b7b7),
                              ),
                            ),
                            Container(
                              // autogroupprsp4Lp (XVEwaYgyc7X7BWrnCfPRSp)
                              margin: EdgeInsets.fromLTRB(33*fem, 0*fem, 1*fem, 21*fem),
                              width: double.infinity,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Container(
                                    // pengaturanumunaa4 (225:1758)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 99*fem, 1*fem),
                                    child: Text(
                                      'Pengaturan Umun',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 20*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // rightarrow3hPn (225:1764)
                                    width: 20*fem,
                                    height: 20*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/right-arrow-3.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // line83Ck (225:1769)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 18*fem),
                              width: 279*fem,
                              height: 1*fem,
                              decoration: BoxDecoration (
                                color: Color(0xffb7b7b7),
                              ),
                            ),
                            Container(
                              // autogroupnzz2aTa (XVEwgDCCuKMXXb8xyfNZZ2)
                              margin: EdgeInsets.fromLTRB(32.5*fem, 0*fem, 2*fem, 22*fem),
                              width: double.infinity,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Container(
                                    // pusatbantuan7yJ (225:1759)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 131.5*fem, 0*fem),
                                    child: Text(
                                      'Pusat Bantuan',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 20*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // rightarrow43c4 (225:1765)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                                    width: 20*fem,
                                    height: 20*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/right-arrow-4.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // line9yEp (225:1770)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 20*fem),
                              width: 279*fem,
                              height: 1*fem,
                              decoration: BoxDecoration (
                                color: Color(0xffb7b7b7),
                              ),
                            ),
                            Container(
                              // autogroupeumzWEk (XVEwmi33dbxagqXVuaEuMz)
                              margin: EdgeInsets.fromLTRB(33.5*fem, 0*fem, 2*fem, 0*fem),
                              width: double.infinity,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // berimasukanFCL (225:1760)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 139.5*fem, 0*fem),
                                    child: Text(
                                      'Beri Masukan',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Inter',
                                        fontSize: 20*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.2125*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // rightarrow5yPE (225:1766)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                                    width: 20*fem,
                                    height: 20*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/right-arrow-5.png',
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // autogroupbujchKE (XVEx9Xk1yq9S91Byn8bUJc)
                      left: 0*fem,
                      top: 329*fem,
                      child: Container(
                        width: 338*fem,
                        height: 45*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                          borderRadius: BorderRadius.circular(10*fem),
                        ),
                        child: Center(
                          child: Text(
                            'Log out',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 20*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.2125*ffem/fem,
                              color: Color(0xff496454),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // personyGk (233:734)
                      left: 7*fem,
                      top: 19*fem,
                      child: Align(
                        child: SizedBox(
                          width: 30*fem,
                          height: 26.47*fem,
                          child: Image.asset(
                            'assets/page-1/images/person.png',
                            width: 30*fem,
                            height: 26.47*fem,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group217H2Y (225:1772)
              left: 0*fem,
              top: 291*fem,
              child: Container(
                width: 375*fem,
                height: 521*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // autogroup94alnEC (XVExpgHTMWJH13UKfs94AL)
                      left: 0*fem,
                      top: 441*fem,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(37.5*fem, 12*fem, 22*fem, 12*fem),
                        width: 375*fem,
                        height: 80*fem,
                        decoration: BoxDecoration (
                          color: Color(0xfff3f4f9),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // autogroup2zmzFtU (XVExykrfHXMgg3WPJB2ZMz)
                              margin: EdgeInsets.fromLTRB(0*fem, 4*fem, 53*fem, 0*fem),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // iconPjn (225:1776)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                    width: 24*fem,
                                    height: 24*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/icon.png',
                                      width: 24*fem,
                                      height: 24*fem,
                                    ),
                                  ),
                                  Text(
                                    // labeltexti1N (225:1777)
                                    'Home',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.3333333333*ffem/fem,
                                      letterSpacing: 0.5*fem,
                                      color: Color(0xff001c38),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // autogroupdhj62nk (XVEy51CvAS7h444STTDhj6)
                              margin: EdgeInsets.fromLTRB(0*fem, 6.55*fem, 46*fem, 0*fem),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // searchmEY (225:1782)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 14.55*fem),
                                    width: 18.9*fem,
                                    height: 18.9*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/search-uE8.png',
                                      width: 18.9*fem,
                                      height: 18.9*fem,
                                    ),
                                  ),
                                  Text(
                                    // labeltextsYU (225:1779)
                                    'Search',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.3333333333*ffem/fem,
                                      letterSpacing: 0.5*fem,
                                      color: Color(0xff001c38),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // labeltext1Pn (225:1780)
                              margin: EdgeInsets.fromLTRB(0*fem, 40*fem, 31.5*fem, 0*fem),
                              child: Text(
                                'Announ',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Roboto',
                                  fontSize: 12*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.3333333333*ffem/fem,
                                  letterSpacing: 0.5*fem,
                                  color: Color(0xff001c38),
                                ),
                              ),
                            ),
                            Container(
                              // autogrouprswa8DW (XVEyAAiyktG1qeffhBrSwa)
                              width: 64*fem,
                              height: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // autogroupnprp5Pe (XVEyFAaenRAySRPF5qNPrp)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                    padding: EdgeInsets.fromLTRB(17*fem, 3*fem, 17*fem, 2.53*fem),
                                    width: double.infinity,
                                    decoration: BoxDecoration (
                                      image: DecorationImage (
                                        fit: BoxFit.cover,
                                        image: AssetImage (
                                          'assets/page-1/images/active-indicator-e8Q.png',
                                        ),
                                      ),
                                    ),
                                    child: Center(
                                      // personPQL (233:740)
                                      child: SizedBox(
                                        width: 30*fem,
                                        height: 26.47*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/person-zQg.png',
                                          width: 30*fem,
                                          height: 26.47*fem,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Text(
                                    // labeltextutU (225:1781)
                                    'Saya',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.3333333333*ffem/fem,
                                      letterSpacing: 0.5*fem,
                                      color: Color(0xff001c38),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // autogrouposkjrHv (XVEyVzVHJ6gV3ueKQgoSKJ)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(31*fem, 0*fem, 31*fem, 283*fem),
                        width: 375*fem,
                        height: 441*fem,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              // settings9Xv (225:1774)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 46*fem),
                              width: 19.49*fem,
                              height: 20*fem,
                              child: Image.asset(
                                'assets/page-1/images/settings-Xix.png',
                                width: 19.49*fem,
                                height: 20*fem,
                              ),
                            ),
                            Container(
                              // infocircleTYc (225:1778)
                              margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 48*fem),
                              width: 20*fem,
                              height: 20*fem,
                              child: Image.asset(
                                'assets/page-1/images/info-circle.png',
                                width: 20*fem,
                                height: 20*fem,
                              ),
                            ),
                            Container(
                              // iconssmsaNL (228:880)
                              width: 24*fem,
                              height: 24*fem,
                              child: Image.asset(
                                'assets/page-1/images/icons-sms.png',
                                width: 24*fem,
                                height: 24*fem,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // megaphoneWWt (246:688)
                      left: 222*fem,
                      top: 460*fem,
                      child: Align(
                        child: SizedBox(
                          width: 24*fem,
                          height: 24*fem,
                          child: Image.asset(
                            'assets/page-1/images/megaphone-Uqv.png',
                            width: 24*fem,
                            height: 24*fem,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // rectangle13DRJ (225:1783)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 375*fem,
                  height: 129*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // yosepmulyadiGuN (225:1784)
              left: 64*fem,
              top: 77*fem,
              child: Align(
                child: SizedBox(
                  width: 83*fem,
                  height: 15*fem,
                  child: Text(
                    'Yosep Mulyadi',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // universitasipendidikanindonesi (225:1785)
              left: 63*fem,
              top: 99*fem,
              child: Align(
                child: SizedBox(
                  width: 159*fem,
                  height: 13*fem,
                  child: Text(
                    'Universitasi Pendidikan Indonesia',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 10*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line5TU4 (225:1786)
              left: 64*fem,
              top: 96*fem,
              child: Align(
                child: SizedBox(
                  width: 155*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff000000),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group219rg (225:1787)
              left: 327*fem,
              top: 54*fem,
              child: Align(
                child: SizedBox(
                  width: 30*fem,
                  height: 30*fem,
                  child: Image.asset(
                    'assets/page-1/images/group-21-sKv.png',
                    width: 30*fem,
                    height: 30*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // bellsGt (225:1789)
              left: 333*fem,
              top: 61*fem,
              child: Align(
                child: SizedBox(
                  width: 18*fem,
                  height: 18*fem,
                  child: Image.asset(
                    'assets/page-1/images/bell-ma8.png',
                    width: 18*fem,
                    height: 18*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse10aBJ (225:1790)
              left: 7*fem,
              top: 69*fem,
              child: Align(
                child: SizedBox(
                  width: 49*fem,
                  height: 49*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(24.5*fem),
                      color: Color(0xfffaf8ee),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // notifremovebgpreview2sgC (225:1791)
              left: 324*fem,
              top: 79*fem,
              child: Align(
                child: SizedBox(
                  width: 35*fem,
                  height: 31*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Container(
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // avaremovebgpreview1BRz (225:1792)
              left: 9*fem,
              top: 71*fem,
              child: Align(
                child: SizedBox(
                  width: 45*fem,
                  height: 45*fem,
                  child: Image.asset(
                    'assets/page-1/images/ava-removebg-preview-1-2X2.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}