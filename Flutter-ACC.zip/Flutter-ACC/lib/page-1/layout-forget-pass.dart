import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // layoutforgetpassYSU (60:128)
        width: double.infinity,
        height: 812*fem,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
          image: DecorationImage (
            fit: BoxFit.cover,
            image: AssetImage (
              'assets/page-1/images/layout-awal-1-bg-uM2.png',
            ),
          ),
        ),
        child: Stack(
          children: [
            Positioned(
              // rectangle10DYc (191:287)
              left: 0*fem,
              top: 752*fem,
              child: Align(
                child: SizedBox(
                  width: 375*fem,
                  height: 60*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xb2ffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle118Qg (191:288)
              left: 0*fem,
              top: 761*fem,
              child: Align(
                child: SizedBox(
                  width: 188*fem,
                  height: 51*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff496454),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle12SgG (191:289)
              left: 195*fem,
              top: 761*fem,
              child: Align(
                child: SizedBox(
                  width: 180*fem,
                  height: 51*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff496454),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // joinnowNK2 (191:290)
              left: 27*fem,
              top: 773*fem,
              child: Align(
                child: SizedBox(
                  width: 129*fem,
                  height: 31*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Text(
                      'JOIN NOW',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 25*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.2125*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // signinRo6 (191:291)
              left: 239*fem,
              top: 773*fem,
              child: Align(
                child: SizedBox(
                  width: 92*fem,
                  height: 31*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Text(
                      'SIGN IN',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 25*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.2125*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle9K7n (60:146)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 375*fem,
                  height: 812*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0x7f496454),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle13SiC (60:147)
              left: 39*fem,
              top: 144*fem,
              child: Align(
                child: SizedBox(
                  width: 302*fem,
                  height: 430*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(10*fem),
                      color: Color(0xffffffff),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // signinLHn (60:148)
              left: 60.5*fem,
              top: 184*fem,
              child: Align(
                child: SizedBox(
                  width: 97*fem,
                  height: 37*fem,
                  child: Text(
                    'Sign In',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 30*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // emailEe4 (60:149)
              left: 62*fem,
              top: 264*fem,
              child: Align(
                child: SizedBox(
                  width: 51*fem,
                  height: 25*fem,
                  child: Text(
                    'Email',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff605656),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // passwordwHa (60:150)
              left: 62.5*fem,
              top: 351*fem,
              child: Align(
                child: SizedBox(
                  width: 93*fem,
                  height: 25*fem,
                  child: Text(
                    'Password',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff605656),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // forgetpassword35i (60:151)
              left: 63.5*fem,
              top: 446*fem,
              child: Align(
                child: SizedBox(
                  width: 244*fem,
                  height: 28*fem,
                  child: Text(
                    'FORGET PASSWORD ?',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 23*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff605656),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line2XWg (60:152)
              left: 64*fem,
              top: 329*fem,
              child: Align(
                child: SizedBox(
                  width: 248*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line33E8 (60:153)
              left: 64*fem,
              top: 415*fem,
              child: Align(
                child: SizedBox(
                  width: 248*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // fabMkc (190:253)
              left: 122*fem,
              top: 510*fem,
              child: Container(
                width: 92*fem,
                height: 40*fem,
                decoration: BoxDecoration (
                  color: Color(0xff2f4156),
                  borderRadius: BorderRadius.circular(100*fem),
                ),
                child: Center(
                  child: Center(
                    child: Text(
                      'Cancel',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.4285714286*ffem/fem,
                        letterSpacing: 0.1000000015*fem,
                        color: Color(0xffd7e2ff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // fabQyn (190:254)
              left: 231*fem,
              top: 510*fem,
              child: Container(
                width: 92*fem,
                height: 40*fem,
                decoration: BoxDecoration (
                  color: Color(0xff2f4156),
                  borderRadius: BorderRadius.circular(100*fem),
                ),
                child: Center(
                  child: Center(
                    child: Text(
                      'Sign in',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.4285714286*ffem/fem,
                        letterSpacing: 0.1000000015*fem,
                        color: Color(0xffd7e2ff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle1731A (60:158)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 375*fem,
                  height: 812*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0x7f496454),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle18hrQ (60:159)
              left: 14*fem,
              top: 251*fem,
              child: Align(
                child: SizedBox(
                  width: 348*fem,
                  height: 250*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(10*fem),
                      color: Color(0xffffffff),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line47v8 (60:162)
              left: 36*fem,
              top: 394*fem,
              child: Align(
                child: SizedBox(
                  width: 291*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // emailzj2 (60:161)
              left: 36*fem,
              top: 339*fem,
              child: Align(
                child: SizedBox(
                  width: 38*fem,
                  height: 19*fem,
                  child: Text(
                    'Email',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff605656),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // youwillredeiveapasswordresetem (60:163)
              left: 36*fem,
              top: 400*fem,
              child: Align(
                child: SizedBox(
                  width: 296*fem,
                  height: 37*fem,
                  child: Text(
                    'You will redeive a password reset email if the provided email is already registered',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff605656),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // forgetpasswordaak (60:160)
              left: 31.5*fem,
              top: 268*fem,
              child: Align(
                child: SizedBox(
                  width: 239*fem,
                  height: 37*fem,
                  child: Text(
                    'Forget Password',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 30*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // fabt5e (190:249)
              left: 121*fem,
              top: 448*fem,
              child: Container(
                width: 92*fem,
                height: 40*fem,
                decoration: BoxDecoration (
                  color: Color(0xff2f4156),
                  borderRadius: BorderRadius.circular(100*fem),
                ),
                child: Center(
                  child: Center(
                    child: Text(
                      'Cancel',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.4285714286*ffem/fem,
                        letterSpacing: 0.1000000015*fem,
                        color: Color(0xffd7e2ff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // fab9GU (190:250)
              left: 230*fem,
              top: 448*fem,
              child: Container(
                width: 80*fem,
                height: 40*fem,
                decoration: BoxDecoration (
                  color: Color(0xff2f4156),
                  borderRadius: BorderRadius.circular(100*fem),
                ),
                child: Center(
                  child: Center(
                    child: Text(
                      'Send',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.4285714286*ffem/fem,
                        letterSpacing: 0.1000000015*fem,
                        color: Color(0xffd7e2ff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}