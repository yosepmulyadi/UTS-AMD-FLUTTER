import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // layoutprofilJWU (225:1812)
        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 380*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfffaf8ee),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroup1wvny6p (XVFLndX4g84JuaXzd61WVn)
              padding: EdgeInsets.fromLTRB(12*fem, 30*fem, 135*fem, 15*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // image7eTr (225:1814)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 87.5*fem, 0*fem),
                    width: 25.5*fem,
                    height: 24*fem,
                    child: Image.asset(
                      'assets/page-1/images/image-7-MAY.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                  Text(
                    // headlineN8x (225:1815)
                    'Profil Saya',
                    style: SafeGoogleFont (
                      'Roboto',
                      fontSize: 24*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.3333333333*ffem/fem,
                      color: Color(0xff001e2f),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 1*fem,
            ),
            Container(
              // autogroupqxcggQY (XVFM2hwwdg2gBMHde3Qxcg)
              padding: EdgeInsets.fromLTRB(16.5*fem, 22*fem, 16.5*fem, 23*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Text(
                'Foto',
                textAlign: TextAlign.center,
                style: SafeGoogleFont (
                  'Inter',
                  fontSize: 20*ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.2125*ffem/fem,
                  color: Color(0xff000000),
                ),
              ),
            ),
            SizedBox(
              height: 1*fem,
            ),
            Container(
              // rectangle784R6 (225:1825)
              width: double.infinity,
              height: 70*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 1*fem,
            ),
            Container(
              // rectangle79yY4 (225:1826)
              width: double.infinity,
              height: 70*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 1*fem,
            ),
            Container(
              // rectangle80gSU (225:1827)
              width: double.infinity,
              height: 70*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 1*fem,
            ),
            Container(
              // rectangle81jvY (225:1828)
              width: double.infinity,
              height: 70*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}