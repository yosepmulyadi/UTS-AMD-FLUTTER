import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // layouthomejR2 (60:235)
        width: double.infinity,
        height: 812*fem,
        decoration: BoxDecoration (
          color: Color(0xfffaf8ee),
        ),
        child: Stack(
          children: [
            Positioned(
              // group54iC (101:65)
              left: 0*fem,
              top: 131*fem,
              child: Container(
                width: 377*fem,
                height: 1393*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // screenshot20230306at03481AmE (90:39)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 4*fem),
                      width: 375*fem,
                      height: 107*fem,
                      child: Image.asset(
                        'assets/page-1/images/screen-shot-2023-03-06-at-0348-1.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                    Container(
                      // screenshot20230306at03482V2p (90:45)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 3*fem),
                      width: 375*fem,
                      height: 107*fem,
                      child: Image.asset(
                        'assets/page-1/images/screen-shot-2023-03-06-at-0348-2.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                    Container(
                      // screenshot20230306at03491CT2 (90:46)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 4*fem),
                      width: 374*fem,
                      height: 107*fem,
                      child: Image.asset(
                        'assets/page-1/images/screen-shot-2023-03-06-at-0349-1.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                    Container(
                      // screenshot20230306at034927K6 (90:47)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 5*fem),
                      width: 375*fem,
                      height: 107*fem,
                      child: Image.asset(
                        'assets/page-1/images/screen-shot-2023-03-06-at-0349-2.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                    Container(
                      // screenshot20230306at03493EPi (90:49)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 5*fem),
                      width: 374*fem,
                      height: 98*fem,
                      child: Image.asset(
                        'assets/page-1/images/screen-shot-2023-03-06-at-0349-3.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                    Container(
                      // autogroupkqdaxac (XVEr3sZy5Qvvt3XfypkqDA)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 4*fem),
                      width: 375*fem,
                      height: 210*fem,
                      child: Stack(
                        children: [
                          Positioned(
                            // screenshot20230306at035616B2 (90:50)
                            left: 0*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 375*fem,
                                height: 98*fem,
                                child: Image.asset(
                                  'assets/page-1/images/screen-shot-2023-03-06-at-0356-1.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // screenshot20230306at10431QxQ (97:53)
                            left: 1*fem,
                            top: 103*fem,
                            child: Align(
                              child: SizedBox(
                                width: 374*fem,
                                height: 107*fem,
                                child: Image.asset(
                                  'assets/page-1/images/screen-shot-2023-03-06-at-1043-1.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // group217L5N (216:511)
                            left: 0*fem,
                            top: 54*fem,
                            child: Container(
                              padding: EdgeInsets.fromLTRB(23*fem, 12*fem, 33*fem, 12*fem),
                              width: 375*fem,
                              height: 80*fem,
                              decoration: BoxDecoration (
                                color: Color(0xfff3f4f9),
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // autogroupdu1eDur (XVErKSxM9DyaqFJBcaDU1E)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 38.5*fem, 0*fem),
                                    width: 64*fem,
                                    height: double.infinity,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // autogroup3nxikPz (XVErT2a3xyxhppKNd63nXi)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                          padding: EdgeInsets.fromLTRB(20*fem, 4*fem, 20*fem, 4*fem),
                                          width: double.infinity,
                                          decoration: BoxDecoration (
                                            image: DecorationImage (
                                              fit: BoxFit.cover,
                                              image: AssetImage (
                                                'assets/page-1/images/active-indicator.png',
                                              ),
                                            ),
                                          ),
                                          child: Center(
                                            // icon3P6 (216:508)
                                            child: SizedBox(
                                              width: 24*fem,
                                              height: 24*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/icon-ftC.png',
                                                width: 24*fem,
                                                height: 24*fem,
                                              ),
                                            ),
                                          ),
                                        ),
                                        Text(
                                          // labeltextNgG (200:347)
                                          'Home',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 12*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1.3333333333*ffem/fem,
                                            letterSpacing: 0.5*fem,
                                            color: Color(0xff001c38),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // autogroupuxvjggx (XVErYcF5yjBSaUejUYUXVJ)
                                    margin: EdgeInsets.fromLTRB(0*fem, 6.55*fem, 46*fem, 0*fem),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // searchQsr (200:313)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 14.55*fem),
                                          width: 18.9*fem,
                                          height: 18.9*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/search.png',
                                            width: 18.9*fem,
                                            height: 18.9*fem,
                                          ),
                                        ),
                                        Text(
                                          // labeltextide (216:272)
                                          'Search',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 12*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1.3333333333*ffem/fem,
                                            letterSpacing: 0.5*fem,
                                            color: Color(0xff001c38),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // autogrouphgbzqiG (XVErec56QmUbJCiDwihGBz)
                                    margin: EdgeInsets.fromLTRB(0*fem, 6*fem, 42.5*fem, 0*fem),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // infocirclemrp (216:359)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 14*fem),
                                          width: 20*fem,
                                          height: 20*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/info-circle-kue.png',
                                            width: 20*fem,
                                            height: 20*fem,
                                          ),
                                        ),
                                        Text(
                                          // labeltextVH2 (216:373)
                                          'Announ',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 12*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1.3333333333*ffem/fem,
                                            letterSpacing: 0.5*fem,
                                            color: Color(0xff001c38),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // autogrouptqz62Xr (XVErjrRMHgEbgDGH6ztQZ6)
                                    margin: EdgeInsets.fromLTRB(0*fem, 7*fem, 0*fem, 0*fem),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // settingse3S (216:505)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.51*fem, 13*fem),
                                          width: 19.49*fem,
                                          height: 20*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/settings-qzg.png',
                                            width: 19.49*fem,
                                            height: 20*fem,
                                          ),
                                        ),
                                        Text(
                                          // labeltextZAQ (216:271)
                                          'Setting',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 12*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1.3333333333*ffem/fem,
                                            letterSpacing: 0.5*fem,
                                            color: Color(0xff001c38),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // screenshot20230306at10461h1i (97:54)
                      margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 4*fem),
                      width: 371*fem,
                      height: 107*fem,
                      child: Image.asset(
                        'assets/page-1/images/screen-shot-2023-03-06-at-1046-1.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                    Container(
                      // screenshot20230306at10481cPa (97:55)
                      margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 4*fem),
                      width: 371*fem,
                      height: 106*fem,
                      child: Image.asset(
                        'assets/page-1/images/screen-shot-2023-03-06-at-1048-1.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                    Container(
                      // screenshot20230306at10482iSc (97:56)
                      margin: EdgeInsets.fromLTRB(4*fem, 0*fem, 0*fem, 5*fem),
                      width: 373*fem,
                      height: 107*fem,
                      child: Image.asset(
                        'assets/page-1/images/screen-shot-2023-03-06-at-1048-2.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                    Container(
                      // screenshot20230306at12591Efr (100:60)
                      margin: EdgeInsets.fromLTRB(4*fem, 0*fem, 0*fem, 5*fem),
                      width: 373*fem,
                      height: 98*fem,
                      child: Image.asset(
                        'assets/page-1/images/screen-shot-2023-03-06-at-1259-1.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                    Container(
                      // screenshot20230306at12592w4U (100:61)
                      margin: EdgeInsets.fromLTRB(4*fem, 0*fem, 0*fem, 0*fem),
                      width: 373*fem,
                      height: 98*fem,
                      child: Image.asset(
                        'assets/page-1/images/screen-shot-2023-03-06-at-1259-2.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                    Container(
                      // rectangle25RkL (101:63)
                      margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                      width: 376*fem,
                      height: 98*fem,
                      decoration: BoxDecoration (
                        color: Color(0xfffaf8ee),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // rectangle13Mdz (60:236)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 375*fem,
                  height: 129*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff496454),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // yosepmulyadiyQU (73:8)
              left: 64*fem,
              top: 77*fem,
              child: Align(
                child: SizedBox(
                  width: 83*fem,
                  height: 15*fem,
                  child: Text(
                    'Yosep Mulyadi',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // universitasipendidikanindonesi (73:10)
              left: 63*fem,
              top: 99*fem,
              child: Align(
                child: SizedBox(
                  width: 159*fem,
                  height: 13*fem,
                  child: Text(
                    'Universitasi Pendidikan Indonesia',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 10*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line5tfr (73:9)
              left: 64*fem,
              top: 96*fem,
              child: Align(
                child: SizedBox(
                  width: 155*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group21XTv (166:188)
              left: 327*fem,
              top: 80*fem,
              child: Align(
                child: SizedBox(
                  width: 30*fem,
                  height: 30*fem,
                  child: Image.asset(
                    'assets/page-1/images/group-21-LSU.png',
                    width: 30*fem,
                    height: 30*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // bellRpC (188:462)
              left: 333*fem,
              top: 87*fem,
              child: Align(
                child: SizedBox(
                  width: 18*fem,
                  height: 18*fem,
                  child: Image.asset(
                    'assets/page-1/images/bell-3vG.png',
                    width: 18*fem,
                    height: 18*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse10MC4 (73:14)
              left: 7*fem,
              top: 69*fem,
              child: Align(
                child: SizedBox(
                  width: 49*fem,
                  height: 49*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(24.5*fem),
                      color: Color(0xfffaf8ee),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // notifremovebgpreview2FoE (73:13)
              left: 324*fem,
              top: 79*fem,
              child: Align(
                child: SizedBox(
                  width: 35*fem,
                  height: 31*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Container(
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // avaremovebgpreview1kjz (73:7)
              left: 9*fem,
              top: 71*fem,
              child: Align(
                child: SizedBox(
                  width: 45*fem,
                  height: 45*fem,
                  child: Image.asset(
                    'assets/page-1/images/ava-removebg-preview-1-7VS.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}