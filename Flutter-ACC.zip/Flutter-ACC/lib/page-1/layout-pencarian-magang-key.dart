import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // layoutpencarianmagangkeythe (149:11)
        width: double.infinity,
        height: 812*fem,
        decoration: BoxDecoration (
          color: Color(0xfffaf8ee),
        ),
        child: Stack(
          children: [
            Positioned(
              // rectangle3786C (149:12)
              left: 0*fem,
              top: 165*fem,
              child: Align(
                child: SizedBox(
                  width: 376*fem,
                  height: 1146*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line8QZW (149:13)
              left: 59*fem,
              top: 236*fem,
              child: Align(
                child: SizedBox(
                  width: 279*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffb7b7b7),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse15tDn (149:14)
              left: 9*fem,
              top: 180*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      border: Border.all(color: Color(0xff8b8b8b)),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group10asJ (149:16)
              left: 9*fem,
              top: 180*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Image.asset(
                    'assets/page-1/images/group-10-SAc.png',
                    width: 50*fem,
                    height: 50*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // ptbumiresourcesmineraltbkVUU (149:19)
              left: 63.5*fem,
              top: 196*fem,
              child: Align(
                child: SizedBox(
                  width: 225*fem,
                  height: 19*fem,
                  child: Text(
                    'PT Bumi Resources Mineral Tbk',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line13AKi (149:20)
              left: 59*fem,
              top: 307*fem,
              child: Align(
                child: SizedBox(
                  width: 279*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffb7b7b7),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ptindmiraF6G (149:21)
              left: 64*fem,
              top: 267*fem,
              child: Align(
                child: SizedBox(
                  width: 87*fem,
                  height: 19*fem,
                  child: Text(
                    'PT INDMIRA',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line14XZa (149:22)
              left: 59*fem,
              top: 378*fem,
              child: Align(
                child: SizedBox(
                  width: 279*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffb7b7b7),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ptsamickindonesia2mE (149:23)
              left: 66.5*fem,
              top: 338*fem,
              child: Align(
                child: SizedBox(
                  width: 148*fem,
                  height: 19*fem,
                  child: Text(
                    'PT Samick Indonesia',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse167ng (149:24)
              left: 9*fem,
              top: 251*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      border: Border.all(color: Color(0xff8b8b8b)),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // maskgroupph6 (149:26)
              left: 9*fem,
              top: 251*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Image.asset(
                    'assets/page-1/images/mask-group-yFv.png',
                    width: 50*fem,
                    height: 50*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse18XrQ (149:29)
              left: 8*fem,
              top: 322*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      border: Border.all(color: Color(0xff8b8b8b)),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // maskgroupSCg (149:31)
              left: 8*fem,
              top: 322*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Image.asset(
                    'assets/page-1/images/mask-group-NoJ.png',
                    width: 50*fem,
                    height: 50*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // line15M4k (149:34)
              left: 60*fem,
              top: 451*fem,
              child: Align(
                child: SizedBox(
                  width: 279*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffb7b7b7),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse15dnx (149:35)
              left: 10*fem,
              top: 395*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      border: Border.all(color: Color(0xff8b8b8b)),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ptparagontechnologyinnovationk (149:36)
              left: 68*fem,
              top: 411*fem,
              child: Align(
                child: SizedBox(
                  width: 247*fem,
                  height: 19*fem,
                  child: Text(
                    'PT Paragon Technology Innovation',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line16eTA (149:37)
              left: 60*fem,
              top: 522*fem,
              child: Align(
                child: SizedBox(
                  width: 279*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffb7b7b7),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ptcentralmegakencanaLqn (149:38)
              left: 69.5*fem,
              top: 482*fem,
              child: Align(
                child: SizedBox(
                  width: 184*fem,
                  height: 19*fem,
                  child: Text(
                    'PT Central Mega Kencana',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line173EQ (149:39)
              left: 60*fem,
              top: 593*fem,
              child: Align(
                child: SizedBox(
                  width: 279*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffb7b7b7),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ptungaransarigarmentsJg8 (149:40)
              left: 69*fem,
              top: 553*fem,
              child: Align(
                child: SizedBox(
                  width: 189*fem,
                  height: 19*fem,
                  child: Text(
                    'PT Ungaran Sari Garments',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse16bv8 (149:41)
              left: 10*fem,
              top: 466*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      border: Border.all(color: Color(0xff8b8b8b)),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse18hiG (149:42)
              left: 9*fem,
              top: 537*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      border: Border.all(color: Color(0xff8b8b8b)),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line18pXz (149:43)
              left: 60*fem,
              top: 664*fem,
              child: Align(
                child: SizedBox(
                  width: 279*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffb7b7b7),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ptpenseinvitationw6p (149:44)
              left: 68*fem,
              top: 624*fem,
              child: Align(
                child: SizedBox(
                  width: 145*fem,
                  height: 19*fem,
                  child: Text(
                    'PT Pensée Invitation',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse19e1E (149:45)
              left: 9*fem,
              top: 608*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      border: Border.all(color: Color(0xff8b8b8b)),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line19YMW (149:46)
              left: 59*fem,
              top: 735*fem,
              child: Align(
                child: SizedBox(
                  width: 279*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffb7b7b7),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse20FFv (149:47)
              left: 9*fem,
              top: 679*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      border: Border.all(color: Color(0xff8b8b8b)),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // pthanallbiopharma9s6 (149:48)
              left: 69*fem,
              top: 695*fem,
              child: Align(
                child: SizedBox(
                  width: 149*fem,
                  height: 19*fem,
                  child: Text(
                    'PT HanAll Biopharma',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line20rFi (149:49)
              left: 59*fem,
              top: 806*fem,
              child: Align(
                child: SizedBox(
                  width: 279*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffb7b7b7),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ptgamainovasiberdikariwY4 (149:50)
              left: 68.5*fem,
              top: 766*fem,
              child: Align(
                child: SizedBox(
                  width: 185*fem,
                  height: 19*fem,
                  child: Text(
                    'PT Gama Inovasi Berdikari',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // pttissannugrahaglobalindodQt (149:52)
              left: 69*fem,
              top: 837*fem,
              child: Align(
                child: SizedBox(
                  width: 219*fem,
                  height: 19*fem,
                  child: Text(
                    'PT Tissan Nugraha Globalindo ',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse21XWG (149:53)
              left: 9*fem,
              top: 750*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      border: Border.all(color: Color(0xff8b8b8b)),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse22eKz (149:54)
              left: 8*fem,
              top: 821*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      border: Border.all(color: Color(0xff8b8b8b)),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ptmayoraindahtbkLyW (149:56)
              left: 69*fem,
              top: 908*fem,
              child: Align(
                child: SizedBox(
                  width: 151*fem,
                  height: 19*fem,
                  child: Text(
                    'PT Mayora Indah Tbk',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse23FKn (149:57)
              left: 8*fem,
              top: 892*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      border: Border.all(color: Color(0xff8b8b8b)),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse24N9W (149:59)
              left: 9*fem,
              top: 963*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      border: Border.all(color: Color(0xff8b8b8b)),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ptcaterpillarindonesiagR6 (149:60)
              left: 67*fem,
              top: 979*fem,
              child: Align(
                child: SizedBox(
                  width: 169*fem,
                  height: 19*fem,
                  child: Text(
                    'PT Caterpillar Indonesia',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ptlabtechpentainternasionalPaQ (149:62)
              left: 67*fem,
              top: 1050*fem,
              child: Align(
                child: SizedBox(
                  width: 222*fem,
                  height: 19*fem,
                  child: Text(
                    'PT Labtech Penta Internasional',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ptcomputradetechnologyinternas (149:64)
              left: 67*fem,
              top: 1121*fem,
              child: Align(
                child: SizedBox(
                  width: 294*fem,
                  height: 19*fem,
                  child: Text(
                    'PT Computrade Technology Internasional',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse25NSL (149:65)
              left: 9*fem,
              top: 1034*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      border: Border.all(color: Color(0xff8b8b8b)),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse26VG4 (149:66)
              left: 8*fem,
              top: 1105*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      border: Border.all(color: Color(0xff8b8b8b)),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ptastrainternasionaltbkbZz (149:68)
              left: 67*fem,
              top: 1192*fem,
              child: Align(
                child: SizedBox(
                  width: 188*fem,
                  height: 19*fem,
                  child: Text(
                    'PT Astra Internasional Tbk',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse27JDW (149:69)
              left: 8*fem,
              top: 1176*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      border: Border.all(color: Color(0xff8b8b8b)),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse31D5a (149:70)
              left: 9*fem,
              top: 608*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      image: DecorationImage (
                        fit: BoxFit.cover,
                        image: AssetImage (
                          'assets/page-1/images/ellipse-31-bg-u7e.png',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse32vEt (149:71)
              left: 9*fem,
              top: 679*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      image: DecorationImage (
                        fit: BoxFit.cover,
                        image: AssetImage (
                          'assets/page-1/images/ellipse-32-bg-2u6.png',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse33RBe (149:72)
              left: 9*fem,
              top: 750*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      image: DecorationImage (
                        fit: BoxFit.cover,
                        image: AssetImage (
                          'assets/page-1/images/ellipse-33-bg-4sr.png',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse36veC (149:73)
              left: 8*fem,
              top: 821*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      image: DecorationImage (
                        fit: BoxFit.cover,
                        image: AssetImage (
                          'assets/page-1/images/ellipse-36-bg-rLg.png',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse35Eet (149:74)
              left: 8*fem,
              top: 892*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      image: DecorationImage (
                        fit: BoxFit.cover,
                        image: AssetImage (
                          'assets/page-1/images/ellipse-35-bg-TaG.png',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse34k7S (149:75)
              left: 10*fem,
              top: 963*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      image: DecorationImage (
                        fit: BoxFit.cover,
                        image: AssetImage (
                          'assets/page-1/images/ellipse-34-bg-Twn.png',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse38TXe (149:76)
              left: 9*fem,
              top: 1034*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      image: DecorationImage (
                        fit: BoxFit.cover,
                        image: AssetImage (
                          'assets/page-1/images/ellipse-38-bg-8Gp.png',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse37yVz (149:77)
              left: 8*fem,
              top: 1105*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      image: DecorationImage (
                        fit: BoxFit.cover,
                        image: AssetImage (
                          'assets/page-1/images/ellipse-37-bg-R7v.png',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse398XJ (149:78)
              left: 8*fem,
              top: 1176*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      image: DecorationImage (
                        fit: BoxFit.cover,
                        image: AssetImage (
                          'assets/page-1/images/ellipse-39-bg-rxQ.png',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // maskgroupSH6 (149:79)
              left: 10*fem,
              top: 395*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Image.asset(
                    'assets/page-1/images/mask-group-KQk.png',
                    width: 50*fem,
                    height: 50*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // maskgroupkHn (149:82)
              left: 10*fem,
              top: 466*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Image.asset(
                    'assets/page-1/images/mask-group-89v.png',
                    width: 50*fem,
                    height: 50*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // maskgroup1Di (149:85)
              left: 9*fem,
              top: 537*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Image.asset(
                    'assets/page-1/images/mask-group-dEG.png',
                    width: 50*fem,
                    height: 50*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // keyboardiP2 (225:1347)
              left: 0*fem,
              top: 513*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(6*fem, 15*fem, 6*fem, 0*fem),
                width: 375*fem,
                height: 302*fem,
                decoration: BoxDecoration (
                  color: Color(0xffeff0f7),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // toolbarPzx (I225:1347;131:1994)
                      margin: EdgeInsets.fromLTRB(4*fem, 0*fem, 4*fem, 11*fem),
                      padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 6.11*fem, 0*fem),
                      width: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // backJME (I225:1347;131:1995)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 36.5*fem, 0*fem),
                            width: 24*fem,
                            height: 24*fem,
                            child: Image.asset(
                              'assets/page-1/images/back-QAU.png',
                              width: 24*fem,
                              height: 24*fem,
                            ),
                          ),
                          Container(
                            // gifccp (I225:1347;131:2012)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 41.95*fem, 0*fem),
                            width: 21*fem,
                            height: 9*fem,
                            child: Image.asset(
                              'assets/page-1/images/gif-8Br.png',
                              width: 21*fem,
                              height: 9*fem,
                            ),
                          ),
                          Container(
                            // pastejSY (I225:1347;131:2018)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 44.67*fem, 0*fem),
                            width: 13.09*fem,
                            height: 16*fem,
                            child: Image.asset(
                              'assets/page-1/images/paste-PyJ.png',
                              width: 13.09*fem,
                              height: 16*fem,
                            ),
                          ),
                          Container(
                            // settingsTNY (I225:1347;131:2024)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 39.22*fem, 0*fem),
                            width: 15.56*fem,
                            height: 16*fem,
                            child: Image.asset(
                              'assets/page-1/images/settings-Ayn.png',
                              width: 15.56*fem,
                              height: 16*fem,
                            ),
                          ),
                          Container(
                            // dividermPE (I225:1347;131:2026)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 39*fem, 0*fem),
                            width: 1*fem,
                            height: 19*fem,
                            decoration: BoxDecoration (
                              color: Color(0xffcfcdd1),
                            ),
                          ),
                          Container(
                            // moregWC (I225:1347;131:2027)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 45.11*fem, 0*fem),
                            width: 16*fem,
                            height: 4*fem,
                            child: Image.asset(
                              'assets/page-1/images/more-a6t.png',
                              width: 16*fem,
                              height: 4*fem,
                            ),
                          ),
                          Container(
                            // voiceoap (I225:1347;131:2029)
                            width: 11.79*fem,
                            height: 16*fem,
                            child: Image.asset(
                              'assets/page-1/images/voice-6Fi.png',
                              width: 11.79*fem,
                              height: 16*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // row1wwv (I225:1347;131:2031)
                      margin: EdgeInsets.fromLTRB(9*fem, 0*fem, 9*fem, 11*fem),
                      width: double.infinity,
                      height: 42*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // keyprimary4Wk (I225:1347;131:2032)
                            padding: EdgeInsets.fromLTRB(8.5*fem, 1*fem, 2*fem, 1*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Center(
                                  // qyNp (I225:1347;131:2036)
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0*fem, 7*fem, 0.5*fem, 0*fem),
                                    child: Text(
                                      'q',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 22*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xff1b1b1d),
                                      ),
                                    ),
                                  ),
                                ),
                                Center(
                                  // 5Ax (I225:1347;131:2034)
                                  child: Text(
                                    '1',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.1725*ffem/fem,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryPhS (I225:1347;131:2037)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Stack(
                              children: [
                                Positioned(
                                  // Kqz (I225:1347;131:2039)
                                  left: 22*fem,
                                  top: 1*fem,
                                  child: Center(
                                    child: Align(
                                      child: SizedBox(
                                        width: 6*fem,
                                        height: 12*fem,
                                        child: Text(
                                          '2',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 10*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1.1725*ffem/fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // wS9v (I225:1347;131:2041)
                                  left: 6.5*fem,
                                  top: 8*fem,
                                  child: Center(
                                    child: Align(
                                      child: SizedBox(
                                        width: 17*fem,
                                        height: 26*fem,
                                        child: Text(
                                          'w',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 22*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.1725*ffem/fem,
                                            color: Color(0xff1b1b1d),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryWQg (I225:1347;131:2042)
                            padding: EdgeInsets.fromLTRB(9*fem, 1*fem, 2*fem, 1*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Center(
                                  // eEba (I225:1347;131:2046)
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0*fem, 7*fem, 1*fem, 0*fem),
                                    child: Text(
                                      'e',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 22*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xff1b1b1d),
                                      ),
                                    ),
                                  ),
                                ),
                                Center(
                                  // ZNx (I225:1347;131:2044)
                                  child: Text(
                                    '3',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.1725*ffem/fem,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimarygyN (I225:1347;131:2047)
                            padding: EdgeInsets.fromLTRB(11*fem, 1*fem, 2*fem, 1*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Center(
                                  // rRRA (I225:1347;131:2051)
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0*fem, 7*fem, 3*fem, 0*fem),
                                    child: Text(
                                      'r',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 22*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xff1b1b1d),
                                      ),
                                    ),
                                  ),
                                ),
                                Center(
                                  // jAx (I225:1347;131:2049)
                                  child: Text(
                                    '4',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.1725*ffem/fem,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryrmN (I225:1347;131:2052)
                            padding: EdgeInsets.fromLTRB(11*fem, 1*fem, 2*fem, 1*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Center(
                                  // tahN (I225:1347;131:2056)
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0*fem, 7*fem, 3*fem, 0*fem),
                                    child: Text(
                                      't',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 22*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xff1b1b1d),
                                      ),
                                    ),
                                  ),
                                ),
                                Center(
                                  // JNU (I225:1347;131:2054)
                                  child: Text(
                                    '5',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.1725*ffem/fem,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryq7W (I225:1347;131:2057)
                            padding: EdgeInsets.fromLTRB(9.5*fem, 1*fem, 2*fem, 1*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Center(
                                  // y98C (I225:1347;131:2061)
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0*fem, 7*fem, 1.5*fem, 0*fem),
                                    child: Text(
                                      'y',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 22*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xff1b1b1d),
                                      ),
                                    ),
                                  ),
                                ),
                                Center(
                                  // fMS (I225:1347;131:2059)
                                  child: Text(
                                    '6',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.1725*ffem/fem,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimarynwr (I225:1347;131:2062)
                            padding: EdgeInsets.fromLTRB(8.5*fem, 1*fem, 2*fem, 1*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Center(
                                  // u7z8 (I225:1347;131:2066)
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0*fem, 7*fem, 0.5*fem, 0*fem),
                                    child: Text(
                                      'u',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 22*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xff1b1b1d),
                                      ),
                                    ),
                                  ),
                                ),
                                Center(
                                  // SFi (I225:1347;131:2064)
                                  child: Text(
                                    '7',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.1725*ffem/fem,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryAhW (I225:1347;131:2067)
                            padding: EdgeInsets.fromLTRB(12*fem, 1*fem, 2*fem, 1*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Center(
                                  // iVjn (I225:1347;131:2071)
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0*fem, 7*fem, 4*fem, 0*fem),
                                    child: Text(
                                      'i',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 22*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xff1b1b1d),
                                      ),
                                    ),
                                  ),
                                ),
                                Center(
                                  // Dvg (I225:1347;131:2069)
                                  child: Text(
                                    '8',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.1725*ffem/fem,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimarymBW (I225:1347;131:2072)
                            padding: EdgeInsets.fromLTRB(8.5*fem, 1*fem, 2*fem, 1*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Center(
                                  // ofng (I225:1347;131:2076)
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0*fem, 7*fem, 0.5*fem, 0*fem),
                                    child: Text(
                                      'o',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 22*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xff1b1b1d),
                                      ),
                                    ),
                                  ),
                                ),
                                Center(
                                  // yYU (I225:1347;131:2074)
                                  child: Text(
                                    '9',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.1725*ffem/fem,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimarygxg (I225:1347;131:2077)
                            padding: EdgeInsets.fromLTRB(8.5*fem, 1*fem, 2*fem, 1*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Center(
                                  // p1VA (I225:1347;131:2081)
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0*fem, 7*fem, 0.5*fem, 0*fem),
                                    child: Text(
                                      'p',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 22*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xff1b1b1d),
                                      ),
                                    ),
                                  ),
                                ),
                                Center(
                                  // L1e (I225:1347;131:2079)
                                  child: Text(
                                    '0',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.1725*ffem/fem,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // row2gLQ (I225:1347;131:2082)
                      margin: EdgeInsets.fromLTRB(26.5*fem, 0*fem, 26.5*fem, 11*fem),
                      width: double.infinity,
                      height: 42*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // keyprimaryneL (I225:1347;131:2083)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'a',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryF28 (I225:1347;131:2087)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  's',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimary7q2 (I225:1347;131:2091)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'd',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryzdv (I225:1347;131:2095)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'f',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimary5fN (I225:1347;131:2099)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'g',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryZqS (I225:1347;131:2103)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'h',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimarySeL (I225:1347;131:2107)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'j',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryJgY (I225:1347;131:2111)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'k',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryyng (I225:1347;131:2115)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'l',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // row3s7N (I225:1347;131:2119)
                      margin: EdgeInsets.fromLTRB(10.5*fem, 0*fem, 10.5*fem, 11*fem),
                      width: double.infinity,
                      height: 42*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // keyfunctionmiY (I225:1347;131:2120)
                            width: 46*fem,
                            height: 42*fem,
                            child: Image.asset(
                              'assets/page-1/images/key-function-eE4.png',
                              width: 46*fem,
                              height: 42*fem,
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimary6F2 (I225:1347;131:2123)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'z',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryMwe (I225:1347;131:2127)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'x',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryF1S (I225:1347;131:2131)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'c',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryUPz (I225:1347;131:2135)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'v',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimary2K2 (I225:1347;131:2139)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'b',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryViQ (I225:1347;131:2143)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'n',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryBLL (I225:1347;131:2147)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'm',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyfunctionrSU (I225:1347;131:2151)
                            width: 46*fem,
                            height: 42*fem,
                            child: Image.asset(
                              'assets/page-1/images/key-function-Z8k.png',
                              width: 46*fem,
                              height: 42*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // functionsBje (I225:1347;131:2154)
                      margin: EdgeInsets.fromLTRB(6*fem, 0*fem, 6*fem, 31*fem),
                      width: double.infinity,
                      height: 42*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // keyspecialfunctionufe (I225:1347;131:2155)
                            width: 49*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffd9e2f8),
                              borderRadius: BorderRadius.circular(30*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  '?123',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 15*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyfunctionP52 (I225:1347;131:2157)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffd9e2f8),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  ',',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimary4BA (I225:1347;131:2159)
                            width: 30*fem,
                            height: 42*fem,
                            child: Image.asset(
                              'assets/page-1/images/key-primary-zHv.png',
                              width: 30*fem,
                              height: 42*fem,
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryBWg (I225:1347;131:2164)
                            width: 140*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyfunctionXKe (I225:1347;131:2166)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffd9e2f8),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  '.',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyspecialfunction1kc (I225:1347;131:2168)
                            width: 47*fem,
                            height: 42*fem,
                            child: Image.asset(
                              'assets/page-1/images/key-special-function-xMv.png',
                              width: 47*fem,
                              height: 42*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // home9bv (I225:1347;131:2173)
                      padding: EdgeInsets.fromLTRB(146*fem, 8*fem, 145*fem, 8*fem),
                      width: double.infinity,
                      height: 20*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffeceff4),
                      ),
                      child: Center(
                        // homesnp (I225:1347;131:2173;102:1037)
                        child: SizedBox(
                          width: double.infinity,
                          height: 4*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(8*fem),
                              color: Color(0xff1e1e1e),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // rectangle35pTA (149:90)
              left: 0*fem,
              top: 129*fem,
              child: Align(
                child: SizedBox(
                  width: 375*fem,
                  height: 32*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // lowongankerjaXsN (149:91)
              left: 17.5*fem,
              top: 133*fem,
              child: Align(
                child: SizedBox(
                  width: 149*fem,
                  height: 25*fem,
                  child: Text(
                    'Lowongan kerja',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // magangdQc (149:93)
              left: 236.5*fem,
              top: 133*fem,
              child: Align(
                child: SizedBox(
                  width: 77*fem,
                  height: 25*fem,
                  child: Text(
                    'Magang',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line128sA (149:94)
              left: 210*fem,
              top: 165*fem,
              child: Align(
                child: SizedBox(
                  width: 161*fem,
                  height: 3*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff496454),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle5s44 (149:107)
              left: 341*fem,
              top: 11*fem,
              child: Align(
                child: SizedBox(
                  width: 20*fem,
                  height: 9*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffd9d9d9),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle8zPa (149:108)
              left: 362*fem,
              top: 14*fem,
              child: Align(
                child: SizedBox(
                  width: 1*fem,
                  height: 2*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffd9d9d9),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle6jMA (149:109)
              left: 342*fem,
              top: 12*fem,
              child: Align(
                child: SizedBox(
                  width: 18*fem,
                  height: 7*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group205R2 (149:110)
              left: 0*fem,
              top: 0*fem,
              child: Container(
                width: 375*fem,
                height: 136*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // rectangle13DXE (149:111)
                      left: 0*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 375*fem,
                          height: 129*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              color: Color(0xff496454),
                              boxShadow: [
                                BoxShadow(
                                  color: Color(0x3f000000),
                                  offset: Offset(0*fem, 4*fem),
                                  blurRadius: 2*fem,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // batalvgY (149:113)
                      left: 311.5*fem,
                      top: 82*fem,
                      child: Align(
                        child: SizedBox(
                          width: 48*fem,
                          height: 25*fem,
                          child: Text(
                            'Batal',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 20*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125*ffem/fem,
                              color: Color(0xfffaf8ee),
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // textfieldsearchdL4 (188:402)
                      left: 17*fem,
                      top: 66*fem,
                      child: Container(
                        width: 264*fem,
                        height: 70*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(8*fem),
                        ),
                        child: Container(
                          // autogroupcgkjwbe (XVFHcioW6uf2r1McFgcGKJ)
                          width: double.infinity,
                          height: 50*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // bgULg (I188:402;13:9701)
                                left: 0*fem,
                                top: 10*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 264*fem,
                                    height: 40*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(8*fem),
                                        color: Color(0x7fe0e0e0),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // textfieldBkt (I188:402;13:9951)
                                left: 0*fem,
                                top: 10*fem,
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(12*fem, 8*fem, 12*fem, 8*fem),
                                  width: 49*fem,
                                  height: 40*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(8*fem),
                                  ),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // captionUzt (I188:402;13:9959)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                        child: Text(
                                          'PT',
                                          style: SafeGoogleFont (
                                            'IBM Plex Sans',
                                            fontSize: 16*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.5*ffem/fem,
                                            letterSpacing: 0.2687999916*fem,
                                            color: Color(0xff818181),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // caretteBuJ (I188:402;13:10108)
                                        width: 3*fem,
                                        height: 24*fem,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(1*fem),
                                          color: Color(0xff1572ec),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Positioned(
                                // iconsrw7n (I188:402;13:9715)
                                left: 228*fem,
                                top: 18*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 24*fem,
                                    height: 24*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/icons-r-HYc.png',
                                      width: 24*fem,
                                      height: 24*fem,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}