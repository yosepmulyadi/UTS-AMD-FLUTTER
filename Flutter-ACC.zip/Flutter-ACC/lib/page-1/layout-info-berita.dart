import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // layoutinfoberitaSPz (165:50)
        width: double.infinity,
        height: 812*fem,
        decoration: BoxDecoration (
          color: Color(0xfffaf8ee),
        ),
        child: Stack(
          children: [
            Positioned(
              // autogroupmmfnkfa (XVF68PH7uqutFD7WrmmMFn)
              left: 0*fem,
              top: 0*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(0*fem, 129*fem, 0*fem, 4*fem),
                width: 375*fem,
                height: 479*fem,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // rectangle384RN (165:51)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 0*fem),
                      width: double.infinity,
                      height: 32*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffffffff),
                      ),
                    ),
                    Container(
                      // autogroupfk8ko84 (XVF4tb1RJHbSoLHH5kFK8k)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 0*fem),
                      width: double.infinity,
                      height: 314*fem,
                      child: Stack(
                        children: [
                          Positioned(
                            // line29XZr (165:54)
                            left: 284*fem,
                            top: 5*fem,
                            child: Align(
                              child: SizedBox(
                                width: 73*fem,
                                height: 3*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xff496454),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // rectangle27Sgp (166:133)
                            left: 0*fem,
                            top: 54*fem,
                            child: Align(
                              child: SizedBox(
                                width: 375*fem,
                                height: 260*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    color: Color(0xffffffff),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x3f000000),
                                        offset: Offset(0*fem, 4*fem),
                                        blurRadius: 2*fem,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // webinabersamadenganemailinikam (166:134)
                            left: 38.5*fem,
                            top: 94*fem,
                            child: Align(
                              child: SizedBox(
                                width: 302*fem,
                                height: 205*fem,
                                child: Text(
                                  'WebinaBersama dengan email ini, kami mengundang Bapak/Ibu Totok beserta mahasiswa STMIK AKAKOM Yogyakarta untuk menghadiri acara Prosple InsideTalks (webinar) bertemakan "How to get Management Trainee (MT) Jobs in Banking" yang akan diadakan pada:Hari, tanggal: Sabtu, 12 Maret 2022Jam: 11.00 WIBVia: Zoom (registrasi: https://bit.ly/prospleid-webinar)Webinar ini akan menjelaskan mengenai tips, trik dan testimoni cara lulus ikut program Management Trainee di industri Perbankan bersama Pembicara terbaik di bidangnya. Partisipan...',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 13*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff8b8b8b),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // undanganwebinarDDi (166:137)
                            left: 114.5*fem,
                            top: 65*fem,
                            child: Align(
                              child: SizedBox(
                                width: 144*fem,
                                height: 20*fem,
                                child: Text(
                                  'Undangan Webinar',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Inter',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.2125*ffem/fem,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // textfieldsearchWTi (228:777)
                            left: 9*fem,
                            top: 0*fem,
                            child: Container(
                              width: 358*fem,
                              height: 70*fem,
                              decoration: BoxDecoration (
                                borderRadius: BorderRadius.circular(8*fem),
                              ),
                              child: Container(
                                // autogroupabegSMN (XVF5QuUEbKXvmcN37oabEg)
                                width: double.infinity,
                                height: 50*fem,
                                child: Stack(
                                  children: [
                                    Positioned(
                                      // bgBJx (I228:777;13:9701)
                                      left: 0*fem,
                                      top: 10*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 358*fem,
                                          height: 40*fem,
                                          child: Container(
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(8*fem),
                                              color: Color(0x7fe0e0e0),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // textfield5v8 (I228:777;13:9951)
                                      left: 0*fem,
                                      top: 10*fem,
                                      child: Container(
                                        padding: EdgeInsets.fromLTRB(12*fem, 8*fem, 12*fem, 8*fem),
                                        width: 49*fem,
                                        height: 40*fem,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(8*fem),
                                        ),
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // captionyEp (I228:777;13:9959)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                              child: Text(
                                                'PT',
                                                style: SafeGoogleFont (
                                                  'IBM Plex Sans',
                                                  fontSize: 16*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.5*ffem/fem,
                                                  letterSpacing: 0.2687999916*fem,
                                                  color: Color(0xff818181),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              // carettefdS (I228:777;13:10108)
                                              width: 3*fem,
                                              height: 24*fem,
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(1*fem),
                                                color: Color(0xff1572ec),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      // iconsrcHn (I228:777;13:9715)
                                      left: 322*fem,
                                      top: 18*fem,
                                      child: Align(
                                        child: SizedBox(
                                          width: 24*fem,
                                          height: 24*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/icons-r-F52.png',
                                            width: 24*fem,
                                            height: 24*fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // autogrouphrzvha8 (XVF5xUPy9Ehee5dC12HrZv)
              left: 0*fem,
              top: 479*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(38.5*fem, 14*fem, 32.5*fem, 32*fem),
                width: 375*fem,
                height: 169*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x3f000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 2*fem,
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // meetsharingbankrayaZsE (166:138)
                      margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 8*fem),
                      child: Text(
                        'Meet sharing Bank Raya',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Inter',
                          fontSize: 16*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.2125*ffem/fem,
                          color: Color(0xff000000),
                        ),
                      ),
                    ),
                    Container(
                      // halojogjaadalagilhoeventmeetsh (166:136)
                      constraints: BoxConstraints (
                        maxWidth: 304*fem,
                      ),
                      child: Text(
                        'Halo Jogja. Ada lagi lho event Meet & Sharing Bank Raya Sabtu 23 Juli with Muhammad Fahry (VP Information Technology Bank Raya). Yuk segera isi registrasinya sekarang ajak juga Teman Teman mu ke link https://bit.ly/EventRaya02. Free, fasilitas materi, sertifikat, Snack. Sampai jumpa.',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Inter',
                          fontSize: 13*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.2125*ffem/fem,
                          color: Color(0xff8b8b8b),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // group2175UC (246:726)
              left: 0*fem,
              top: 732*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(37.5*fem, 13*fem, 33*fem, 12*fem),
                width: 375*fem,
                height: 80*fem,
                decoration: BoxDecoration (
                  color: Color(0xfff3f4f9),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // autogroupnronmbv (XVF6yShi48GxiNtBcFnRoN)
                      margin: EdgeInsets.fromLTRB(0*fem, 3*fem, 53*fem, 0*fem),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // iconWZW (246:729)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                            width: 24*fem,
                            height: 24*fem,
                            child: Image.asset(
                              'assets/page-1/images/icon-nKi.png',
                              width: 24*fem,
                              height: 24*fem,
                            ),
                          ),
                          Text(
                            // labeltextRwN (246:730)
                            'Home',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.3333333333*ffem/fem,
                              letterSpacing: 0.5*fem,
                              color: Color(0xff001c38),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogrouphxhwZGt (XVF76SW3tfxJZ4Hb9xhxHW)
                      margin: EdgeInsets.fromLTRB(0*fem, 5.55*fem, 37.5*fem, 0*fem),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // searchtpx (246:735)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 14.55*fem),
                            width: 18.9*fem,
                            height: 18.9*fem,
                            child: Image.asset(
                              'assets/page-1/images/search-vYx.png',
                              width: 18.9*fem,
                              height: 18.9*fem,
                            ),
                          ),
                          Text(
                            // labeltextQHW (246:732)
                            'Search',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.3333333333*ffem/fem,
                              letterSpacing: 0.5*fem,
                              color: Color(0xff001c38),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogrouph6pijKn (XVF7C71HBsniu8Zmvxh6Pi)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 32*fem, 0*fem),
                      width: 64*fem,
                      height: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupkqccFJ8 (XVF7HGXLnKw3gjB1AhKqcC)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7*fem),
                            padding: EdgeInsets.fromLTRB(20*fem, 3*fem, 20*fem, 5*fem),
                            width: double.infinity,
                            decoration: BoxDecoration (
                              image: DecorationImage (
                                fit: BoxFit.cover,
                                image: AssetImage (
                                  'assets/page-1/images/active-indicator-VuS.png',
                                ),
                              ),
                            ),
                            child: Center(
                              // megaphonewRr (246:736)
                              child: SizedBox(
                                width: 24*fem,
                                height: 24*fem,
                                child: Image.asset(
                                  'assets/page-1/images/megaphone-ouS.png',
                                  width: 24*fem,
                                  height: 24*fem,
                                ),
                              ),
                            ),
                          ),
                          Container(
                            // labeltextfMr (246:733)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                            child: Text(
                              'Announ',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Roboto',
                                fontSize: 12*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.3333333333*ffem/fem,
                                letterSpacing: 0.5*fem,
                                color: Color(0xff001c38),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroupkaznaDv (XVF7NrCNo59nSPWN29kaZn)
                      margin: EdgeInsets.fromLTRB(0*fem, 6*fem, 0*fem, 0*fem),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // settingsJvc (246:728)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.51*fem, 13*fem),
                            width: 19.49*fem,
                            height: 20*fem,
                            child: Image.asset(
                              'assets/page-1/images/settings-xYx.png',
                              width: 19.49*fem,
                              height: 20*fem,
                            ),
                          ),
                          Text(
                            // labeltextq9r (246:734)
                            'Setting',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.3333333333*ffem/fem,
                              letterSpacing: 0.5*fem,
                              color: Color(0xff001c38),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // rectangle13LcQ (165:67)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 375*fem,
                  height: 129*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff496454),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // yosepmulyadiwcC (165:79)
              left: 64*fem,
              top: 77*fem,
              child: Align(
                child: SizedBox(
                  width: 83*fem,
                  height: 15*fem,
                  child: Text(
                    'Yosep Mulyadi',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // universitasipendidikanindonesi (165:80)
              left: 63*fem,
              top: 99*fem,
              child: Align(
                child: SizedBox(
                  width: 159*fem,
                  height: 13*fem,
                  child: Text(
                    'Universitasi Pendidikan Indonesia',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 10*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line579J (165:81)
              left: 64*fem,
              top: 96*fem,
              child: Align(
                child: SizedBox(
                  width: 155*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse9QPJ (165:82)
              left: 327*fem,
              top: 80*fem,
              child: Align(
                child: SizedBox(
                  width: 30*fem,
                  height: 30*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(15*fem),
                      color: Color(0xfffaf8ee),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse106mv (165:83)
              left: 7*fem,
              top: 69*fem,
              child: Align(
                child: SizedBox(
                  width: 49*fem,
                  height: 49*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(24.5*fem),
                      color: Color(0xfffaf8ee),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // bellZvQ (191:268)
              left: 333*fem,
              top: 87*fem,
              child: Align(
                child: SizedBox(
                  width: 18*fem,
                  height: 18*fem,
                  child: Image.asset(
                    'assets/page-1/images/bell-m9A.png',
                    width: 18*fem,
                    height: 18*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // avaremovebgpreview1GZv (165:85)
              left: 9*fem,
              top: 71*fem,
              child: Align(
                child: SizedBox(
                  width: 45*fem,
                  height: 45*fem,
                  child: Image.asset(
                    'assets/page-1/images/ava-removebg-preview-1-xPa.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle35nHN (165:87)
              left: 0*fem,
              top: 129*fem,
              child: Align(
                child: SizedBox(
                  width: 375*fem,
                  height: 32*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // pengumuman6Yx (165:88)
              left: 18.5*fem,
              top: 134*fem,
              child: Align(
                child: SizedBox(
                  width: 130*fem,
                  height: 25*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Text(
                      'Pengumuman',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2125*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // agendaAYp (165:89)
              left: 180.5*fem,
              top: 134*fem,
              child: Align(
                child: SizedBox(
                  width: 73*fem,
                  height: 25*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Text(
                      'Agenda',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2125*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // beritaeyn (165:90)
              left: 289*fem,
              top: 134*fem,
              child: Align(
                child: SizedBox(
                  width: 56*fem,
                  height: 25*fem,
                  child: Text(
                    'Berita',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}