import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // layoutpengaturanumumhb6 (228:693)
        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 397*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfffaf8ee),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupohwncTA (XVFMnbrUBWFRrvT59noHwn)
              width: double.infinity,
              height: 131*fem,
              child: Stack(
                children: [
                  Positioned(
                    // rectangle77ZNQ (228:694)
                    left: 0*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 375*fem,
                        height: 77*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xffffffff),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x3f000000),
                                offset: Offset(0*fem, 4*fem),
                                blurRadius: 2*fem,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // image7sdz (228:695)
                    left: 12*fem,
                    top: 34*fem,
                    child: Align(
                      child: SizedBox(
                        width: 25.5*fem,
                        height: 24*fem,
                        child: Image.asset(
                          'assets/page-1/images/image-7-Mgc.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // headlinebK6 (228:696)
                    left: 97*fem,
                    top: 30*fem,
                    child: Align(
                      child: SizedBox(
                        width: 199*fem,
                        height: 32*fem,
                        child: Text(
                          'Pengaturan umum',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 24*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.3333333333*ffem/fem,
                            color: Color(0xff001e2f),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle27tJC (228:697)
                    left: 0*fem,
                    top: 61*fem,
                    child: Align(
                      child: SizedBox(
                        width: 375*fem,
                        height: 70*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xffffffff),
                            boxShadow: [
                              BoxShadow(
                                color: Color(0x3f000000),
                                offset: Offset(0*fem, 4*fem),
                                blurRadius: 2*fem,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // pengaturanbahasauyz (228:713)
                    left: 12*fem,
                    top: 100*fem,
                    child: Align(
                      child: SizedBox(
                        width: 184*fem,
                        height: 25*fem,
                        child: Text(
                          'Pengaturan Bahasa',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Inter',
                            fontSize: 20*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.2125*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 1*fem,
            ),
            Container(
              // rectangle781GL (228:698)
              width: double.infinity,
              height: 70*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 1*fem,
            ),
            Container(
              // rectangle79VBW (228:699)
              width: double.infinity,
              height: 70*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 1*fem,
            ),
            Container(
              // rectangle801fe (228:700)
              width: double.infinity,
              height: 70*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 1*fem,
            ),
            Container(
              // rectangle81wZJ (228:701)
              width: double.infinity,
              height: 70*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}