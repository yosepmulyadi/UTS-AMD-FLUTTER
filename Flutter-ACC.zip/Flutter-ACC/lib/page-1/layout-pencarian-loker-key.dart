import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // layoutpencarianlokerkeyiL8 (225:1121)
        width: double.infinity,
        height: 812*fem,
        decoration: BoxDecoration (
          color: Color(0xfffaf8ee),
        ),
        child: Stack(
          children: [
            Positioned(
              // rectangle378ek (225:1122)
              left: 0*fem,
              top: 165*fem,
              child: Align(
                child: SizedBox(
                  width: 376*fem,
                  height: 1146*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line8drQ (225:1123)
              left: 59*fem,
              top: 236*fem,
              child: Align(
                child: SizedBox(
                  width: 279*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffb7b7b7),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse15vKi (225:1124)
              left: 9*fem,
              top: 180*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      border: Border.all(color: Color(0xff8b8b8b)),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group10Qkg (225:1126)
              left: 9*fem,
              top: 180*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Image.asset(
                    'assets/page-1/images/group-10-p9n.png',
                    width: 50*fem,
                    height: 50*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // ptbumiresourcesmineraltbkhDz (225:1129)
              left: 63.5*fem,
              top: 196*fem,
              child: Align(
                child: SizedBox(
                  width: 225*fem,
                  height: 19*fem,
                  child: Text(
                    'PT Bumi Resources Mineral Tbk',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line13MZS (225:1130)
              left: 59*fem,
              top: 307*fem,
              child: Align(
                child: SizedBox(
                  width: 279*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffb7b7b7),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ptindmirackG (225:1131)
              left: 64*fem,
              top: 267*fem,
              child: Align(
                child: SizedBox(
                  width: 87*fem,
                  height: 19*fem,
                  child: Text(
                    'PT INDMIRA',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line146fS (225:1132)
              left: 59*fem,
              top: 378*fem,
              child: Align(
                child: SizedBox(
                  width: 279*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffb7b7b7),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ptsamickindonesiaCCg (225:1133)
              left: 66.5*fem,
              top: 338*fem,
              child: Align(
                child: SizedBox(
                  width: 148*fem,
                  height: 19*fem,
                  child: Text(
                    'PT Samick Indonesia',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse16gNk (225:1134)
              left: 9*fem,
              top: 251*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      border: Border.all(color: Color(0xff8b8b8b)),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // maskgroupyck (225:1136)
              left: 9*fem,
              top: 251*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Image.asset(
                    'assets/page-1/images/mask-group-c5v.png',
                    width: 50*fem,
                    height: 50*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse18HNY (225:1139)
              left: 8*fem,
              top: 322*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      border: Border.all(color: Color(0xff8b8b8b)),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // maskgroupPAg (225:1141)
              left: 8*fem,
              top: 322*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Image.asset(
                    'assets/page-1/images/mask-group-a1n.png',
                    width: 50*fem,
                    height: 50*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // line15gvU (225:1144)
              left: 60*fem,
              top: 451*fem,
              child: Align(
                child: SizedBox(
                  width: 279*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffb7b7b7),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse15zAU (225:1145)
              left: 10*fem,
              top: 395*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      border: Border.all(color: Color(0xff8b8b8b)),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ptparagontechnologyinnovationJ (225:1146)
              left: 68*fem,
              top: 411*fem,
              child: Align(
                child: SizedBox(
                  width: 247*fem,
                  height: 19*fem,
                  child: Text(
                    'PT Paragon Technology Innovation',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line16ns2 (225:1147)
              left: 60*fem,
              top: 522*fem,
              child: Align(
                child: SizedBox(
                  width: 279*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffb7b7b7),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ptcentralmegakencanaHHz (225:1148)
              left: 69.5*fem,
              top: 482*fem,
              child: Align(
                child: SizedBox(
                  width: 184*fem,
                  height: 19*fem,
                  child: Text(
                    'PT Central Mega Kencana',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line17B8U (225:1149)
              left: 60*fem,
              top: 593*fem,
              child: Align(
                child: SizedBox(
                  width: 279*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffb7b7b7),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ptungaransarigarmentsUdN (225:1150)
              left: 69*fem,
              top: 553*fem,
              child: Align(
                child: SizedBox(
                  width: 189*fem,
                  height: 19*fem,
                  child: Text(
                    'PT Ungaran Sari Garments',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse16z5v (225:1151)
              left: 10*fem,
              top: 466*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      border: Border.all(color: Color(0xff8b8b8b)),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse186ek (225:1152)
              left: 9*fem,
              top: 537*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      border: Border.all(color: Color(0xff8b8b8b)),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line18DUU (225:1153)
              left: 60*fem,
              top: 664*fem,
              child: Align(
                child: SizedBox(
                  width: 279*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffb7b7b7),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ptpenseinvitationWiU (225:1154)
              left: 68*fem,
              top: 624*fem,
              child: Align(
                child: SizedBox(
                  width: 145*fem,
                  height: 19*fem,
                  child: Text(
                    'PT Pensée Invitation',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse19DMz (225:1155)
              left: 9*fem,
              top: 608*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      border: Border.all(color: Color(0xff8b8b8b)),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line19vXJ (225:1156)
              left: 59*fem,
              top: 735*fem,
              child: Align(
                child: SizedBox(
                  width: 279*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffb7b7b7),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse20DFW (225:1157)
              left: 9*fem,
              top: 679*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      border: Border.all(color: Color(0xff8b8b8b)),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // pthanallbiopharma7rg (225:1158)
              left: 69*fem,
              top: 695*fem,
              child: Align(
                child: SizedBox(
                  width: 149*fem,
                  height: 19*fem,
                  child: Text(
                    'PT HanAll Biopharma',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line20Dep (225:1159)
              left: 59*fem,
              top: 806*fem,
              child: Align(
                child: SizedBox(
                  width: 279*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffb7b7b7),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ptgamainovasiberdikariiba (225:1160)
              left: 68.5*fem,
              top: 766*fem,
              child: Align(
                child: SizedBox(
                  width: 185*fem,
                  height: 19*fem,
                  child: Text(
                    'PT Gama Inovasi Berdikari',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // pttissannugrahaglobalindoynQ (225:1162)
              left: 69*fem,
              top: 837*fem,
              child: Align(
                child: SizedBox(
                  width: 219*fem,
                  height: 19*fem,
                  child: Text(
                    'PT Tissan Nugraha Globalindo ',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse215Ke (225:1163)
              left: 9*fem,
              top: 750*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      border: Border.all(color: Color(0xff8b8b8b)),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse22Bda (225:1164)
              left: 8*fem,
              top: 821*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      border: Border.all(color: Color(0xff8b8b8b)),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ptmayoraindahtbkVuA (225:1166)
              left: 69*fem,
              top: 908*fem,
              child: Align(
                child: SizedBox(
                  width: 151*fem,
                  height: 19*fem,
                  child: Text(
                    'PT Mayora Indah Tbk',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse23zqv (225:1167)
              left: 8*fem,
              top: 892*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      border: Border.all(color: Color(0xff8b8b8b)),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse24uhz (225:1169)
              left: 9*fem,
              top: 963*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      border: Border.all(color: Color(0xff8b8b8b)),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ptcaterpillarindonesiaEVN (225:1170)
              left: 67*fem,
              top: 979*fem,
              child: Align(
                child: SizedBox(
                  width: 169*fem,
                  height: 19*fem,
                  child: Text(
                    'PT Caterpillar Indonesia',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ptlabtechpentainternasionalYW4 (225:1172)
              left: 67*fem,
              top: 1050*fem,
              child: Align(
                child: SizedBox(
                  width: 222*fem,
                  height: 19*fem,
                  child: Text(
                    'PT Labtech Penta Internasional',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ptcomputradetechnologyinternas (225:1174)
              left: 67*fem,
              top: 1121*fem,
              child: Align(
                child: SizedBox(
                  width: 294*fem,
                  height: 19*fem,
                  child: Text(
                    'PT Computrade Technology Internasional',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse258UG (225:1175)
              left: 9*fem,
              top: 1034*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      border: Border.all(color: Color(0xff8b8b8b)),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse26472 (225:1176)
              left: 8*fem,
              top: 1105*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      border: Border.all(color: Color(0xff8b8b8b)),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ptastrainternasionaltbkmn8 (225:1178)
              left: 67*fem,
              top: 1192*fem,
              child: Align(
                child: SizedBox(
                  width: 188*fem,
                  height: 19*fem,
                  child: Text(
                    'PT Astra Internasional Tbk',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 15*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse27t64 (225:1179)
              left: 8*fem,
              top: 1176*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      border: Border.all(color: Color(0xff8b8b8b)),
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse31bWG (225:1180)
              left: 9*fem,
              top: 608*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      image: DecorationImage (
                        fit: BoxFit.cover,
                        image: AssetImage (
                          'assets/page-1/images/ellipse-31-bg-HDa.png',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse32JQg (225:1181)
              left: 9*fem,
              top: 679*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      image: DecorationImage (
                        fit: BoxFit.cover,
                        image: AssetImage (
                          'assets/page-1/images/ellipse-32-bg-Gpx.png',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse33zYQ (225:1182)
              left: 9*fem,
              top: 750*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      image: DecorationImage (
                        fit: BoxFit.cover,
                        image: AssetImage (
                          'assets/page-1/images/ellipse-33-bg-qyz.png',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse36WFr (225:1183)
              left: 8*fem,
              top: 821*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      image: DecorationImage (
                        fit: BoxFit.cover,
                        image: AssetImage (
                          'assets/page-1/images/ellipse-36-bg-Rxk.png',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse35R7v (225:1184)
              left: 8*fem,
              top: 892*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      image: DecorationImage (
                        fit: BoxFit.cover,
                        image: AssetImage (
                          'assets/page-1/images/ellipse-35-bg-mqJ.png',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse34vqN (225:1185)
              left: 10*fem,
              top: 963*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      image: DecorationImage (
                        fit: BoxFit.cover,
                        image: AssetImage (
                          'assets/page-1/images/ellipse-34-bg-asi.png',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse38SYp (225:1186)
              left: 9*fem,
              top: 1034*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      image: DecorationImage (
                        fit: BoxFit.cover,
                        image: AssetImage (
                          'assets/page-1/images/ellipse-38-bg-ix8.png',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse37Ybr (225:1187)
              left: 8*fem,
              top: 1105*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      image: DecorationImage (
                        fit: BoxFit.cover,
                        image: AssetImage (
                          'assets/page-1/images/ellipse-37-bg-EDN.png',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse39Eja (225:1188)
              left: 8*fem,
              top: 1176*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(25*fem),
                      image: DecorationImage (
                        fit: BoxFit.cover,
                        image: AssetImage (
                          'assets/page-1/images/ellipse-39-bg-8Br.png',
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // maskgroupjwE (225:1189)
              left: 10*fem,
              top: 395*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Image.asset(
                    'assets/page-1/images/mask-group-TS8.png',
                    width: 50*fem,
                    height: 50*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // maskgrouprW4 (225:1192)
              left: 10*fem,
              top: 466*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Image.asset(
                    'assets/page-1/images/mask-group-Kzx.png',
                    width: 50*fem,
                    height: 50*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // maskgroupNUQ (225:1195)
              left: 9*fem,
              top: 537*fem,
              child: Align(
                child: SizedBox(
                  width: 50*fem,
                  height: 50*fem,
                  child: Image.asset(
                    'assets/page-1/images/mask-group-BSg.png',
                    width: 50*fem,
                    height: 50*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // keyboardV3E (225:950)
              left: 0*fem,
              top: 512*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(6*fem, 15*fem, 6*fem, 0*fem),
                width: 375*fem,
                height: 302*fem,
                decoration: BoxDecoration (
                  color: Color(0xffeff0f7),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // toolbarZYt (I225:950;131:1994)
                      margin: EdgeInsets.fromLTRB(4*fem, 0*fem, 4*fem, 11*fem),
                      padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 6.11*fem, 0*fem),
                      width: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // backTeG (I225:950;131:1995)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 36.5*fem, 0*fem),
                            width: 24*fem,
                            height: 24*fem,
                            child: Image.asset(
                              'assets/page-1/images/back-yfn.png',
                              width: 24*fem,
                              height: 24*fem,
                            ),
                          ),
                          Container(
                            // gifBKN (I225:950;131:2012)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 41.95*fem, 0*fem),
                            width: 21*fem,
                            height: 9*fem,
                            child: Image.asset(
                              'assets/page-1/images/gif.png',
                              width: 21*fem,
                              height: 9*fem,
                            ),
                          ),
                          Container(
                            // pastetja (I225:950;131:2018)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 44.67*fem, 0*fem),
                            width: 13.09*fem,
                            height: 16*fem,
                            child: Image.asset(
                              'assets/page-1/images/paste.png',
                              width: 13.09*fem,
                              height: 16*fem,
                            ),
                          ),
                          Container(
                            // settingsp7S (I225:950;131:2024)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 39.22*fem, 0*fem),
                            width: 15.56*fem,
                            height: 16*fem,
                            child: Image.asset(
                              'assets/page-1/images/settings-HXn.png',
                              width: 15.56*fem,
                              height: 16*fem,
                            ),
                          ),
                          Container(
                            // dividerXXe (I225:950;131:2026)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 39*fem, 0*fem),
                            width: 1*fem,
                            height: 19*fem,
                            decoration: BoxDecoration (
                              color: Color(0xffcfcdd1),
                            ),
                          ),
                          Container(
                            // moreGEL (I225:950;131:2027)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 45.11*fem, 0*fem),
                            width: 16*fem,
                            height: 4*fem,
                            child: Image.asset(
                              'assets/page-1/images/more.png',
                              width: 16*fem,
                              height: 4*fem,
                            ),
                          ),
                          Container(
                            // voiceBs6 (I225:950;131:2029)
                            width: 11.79*fem,
                            height: 16*fem,
                            child: Image.asset(
                              'assets/page-1/images/voice.png',
                              width: 11.79*fem,
                              height: 16*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // row18GY (I225:950;131:2031)
                      margin: EdgeInsets.fromLTRB(9*fem, 0*fem, 9*fem, 11*fem),
                      width: double.infinity,
                      height: 42*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // keyprimaryqwe (I225:950;131:2032)
                            padding: EdgeInsets.fromLTRB(8.5*fem, 1*fem, 2*fem, 1*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Center(
                                  // qZMr (I225:950;131:2036)
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0*fem, 7*fem, 0.5*fem, 0*fem),
                                    child: Text(
                                      'q',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 22*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xff1b1b1d),
                                      ),
                                    ),
                                  ),
                                ),
                                Center(
                                  // eu6 (I225:950;131:2034)
                                  child: Text(
                                    '1',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.1725*ffem/fem,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryPLt (I225:950;131:2037)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Stack(
                              children: [
                                Positioned(
                                  // 7ng (I225:950;131:2039)
                                  left: 22*fem,
                                  top: 1*fem,
                                  child: Center(
                                    child: Align(
                                      child: SizedBox(
                                        width: 6*fem,
                                        height: 12*fem,
                                        child: Text(
                                          '2',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 10*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1.1725*ffem/fem,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // wcUY (I225:950;131:2041)
                                  left: 6.5*fem,
                                  top: 8*fem,
                                  child: Center(
                                    child: Align(
                                      child: SizedBox(
                                        width: 17*fem,
                                        height: 26*fem,
                                        child: Text(
                                          'w',
                                          textAlign: TextAlign.center,
                                          style: SafeGoogleFont (
                                            'Roboto',
                                            fontSize: 22*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.1725*ffem/fem,
                                            color: Color(0xff1b1b1d),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryhVz (I225:950;131:2042)
                            padding: EdgeInsets.fromLTRB(9*fem, 1*fem, 2*fem, 1*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Center(
                                  // ecsr (I225:950;131:2046)
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0*fem, 7*fem, 1*fem, 0*fem),
                                    child: Text(
                                      'e',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 22*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xff1b1b1d),
                                      ),
                                    ),
                                  ),
                                ),
                                Center(
                                  // LJ4 (I225:950;131:2044)
                                  child: Text(
                                    '3',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.1725*ffem/fem,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryGhW (I225:950;131:2047)
                            padding: EdgeInsets.fromLTRB(11*fem, 1*fem, 2*fem, 1*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Center(
                                  // r19J (I225:950;131:2051)
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0*fem, 7*fem, 3*fem, 0*fem),
                                    child: Text(
                                      'r',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 22*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xff1b1b1d),
                                      ),
                                    ),
                                  ),
                                ),
                                Center(
                                  // iZW (I225:950;131:2049)
                                  child: Text(
                                    '4',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.1725*ffem/fem,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryEnk (I225:950;131:2052)
                            padding: EdgeInsets.fromLTRB(11*fem, 1*fem, 2*fem, 1*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Center(
                                  // tZq2 (I225:950;131:2056)
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0*fem, 7*fem, 3*fem, 0*fem),
                                    child: Text(
                                      't',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 22*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xff1b1b1d),
                                      ),
                                    ),
                                  ),
                                ),
                                Center(
                                  // Uh6 (I225:950;131:2054)
                                  child: Text(
                                    '5',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.1725*ffem/fem,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryojN (I225:950;131:2057)
                            padding: EdgeInsets.fromLTRB(9.5*fem, 1*fem, 2*fem, 1*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Center(
                                  // yirL (I225:950;131:2061)
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0*fem, 7*fem, 1.5*fem, 0*fem),
                                    child: Text(
                                      'y',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 22*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xff1b1b1d),
                                      ),
                                    ),
                                  ),
                                ),
                                Center(
                                  // qRA (I225:950;131:2059)
                                  child: Text(
                                    '6',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.1725*ffem/fem,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryZrx (I225:950;131:2062)
                            padding: EdgeInsets.fromLTRB(8.5*fem, 1*fem, 2*fem, 1*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Center(
                                  // uVVi (I225:950;131:2066)
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0*fem, 7*fem, 0.5*fem, 0*fem),
                                    child: Text(
                                      'u',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 22*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xff1b1b1d),
                                      ),
                                    ),
                                  ),
                                ),
                                Center(
                                  // Qsa (I225:950;131:2064)
                                  child: Text(
                                    '7',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.1725*ffem/fem,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimarykRe (I225:950;131:2067)
                            padding: EdgeInsets.fromLTRB(12*fem, 1*fem, 2*fem, 1*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Center(
                                  // iAEU (I225:950;131:2071)
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0*fem, 7*fem, 4*fem, 0*fem),
                                    child: Text(
                                      'i',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 22*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xff1b1b1d),
                                      ),
                                    ),
                                  ),
                                ),
                                Center(
                                  // q5i (I225:950;131:2069)
                                  child: Text(
                                    '8',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.1725*ffem/fem,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryjB6 (I225:950;131:2072)
                            padding: EdgeInsets.fromLTRB(8.5*fem, 1*fem, 2*fem, 1*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Center(
                                  // oeYx (I225:950;131:2076)
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0*fem, 7*fem, 0.5*fem, 0*fem),
                                    child: Text(
                                      'o',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 22*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xff1b1b1d),
                                      ),
                                    ),
                                  ),
                                ),
                                Center(
                                  // jqJ (I225:950;131:2074)
                                  child: Text(
                                    '9',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.1725*ffem/fem,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimary4sa (I225:950;131:2077)
                            padding: EdgeInsets.fromLTRB(8.5*fem, 1*fem, 2*fem, 1*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Center(
                                  // pab2 (I225:950;131:2081)
                                  child: Container(
                                    margin: EdgeInsets.fromLTRB(0*fem, 7*fem, 0.5*fem, 0*fem),
                                    child: Text(
                                      'p',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 22*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xff1b1b1d),
                                      ),
                                    ),
                                  ),
                                ),
                                Center(
                                  // J1E (I225:950;131:2079)
                                  child: Text(
                                    '0',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 10*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.1725*ffem/fem,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // row2dZJ (I225:950;131:2082)
                      margin: EdgeInsets.fromLTRB(26.5*fem, 0*fem, 26.5*fem, 11*fem),
                      width: double.infinity,
                      height: 42*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // keyprimaryLic (I225:950;131:2083)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'a',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryCF2 (I225:950;131:2087)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  's',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimary3mS (I225:950;131:2091)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'd',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryWf2 (I225:950;131:2095)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'f',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimarynsS (I225:950;131:2099)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'g',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimary4a4 (I225:950;131:2103)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'h',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryYVE (I225:950;131:2107)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'j',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryCpg (I225:950;131:2111)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'k',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryGZe (I225:950;131:2115)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'l',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // row3LZW (I225:950;131:2119)
                      margin: EdgeInsets.fromLTRB(10.5*fem, 0*fem, 10.5*fem, 11*fem),
                      width: double.infinity,
                      height: 42*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // keyfunctionqFN (I225:950;131:2120)
                            width: 46*fem,
                            height: 42*fem,
                            child: Image.asset(
                              'assets/page-1/images/key-function-f7n.png',
                              width: 46*fem,
                              height: 42*fem,
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryYQg (I225:950;131:2123)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'z',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimarycfS (I225:950;131:2127)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'x',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryu8k (I225:950;131:2131)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'c',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryAKa (I225:950;131:2135)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'v',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimary3PN (I225:950;131:2139)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'b',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryvCG (I225:950;131:2143)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'n',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryzxp (I225:950;131:2147)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'm',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyfunctiongak (I225:950;131:2151)
                            width: 46*fem,
                            height: 42*fem,
                            child: Image.asset(
                              'assets/page-1/images/key-function.png',
                              width: 46*fem,
                              height: 42*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // functionscjJ (I225:950;131:2154)
                      margin: EdgeInsets.fromLTRB(6*fem, 0*fem, 6*fem, 31*fem),
                      width: double.infinity,
                      height: 42*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // keyspecialfunctionLvC (I225:950;131:2155)
                            width: 49*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffd9e2f8),
                              borderRadius: BorderRadius.circular(30*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  '?123',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 15*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyfunctionDUC (I225:950;131:2157)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffd9e2f8),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  ',',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryWiC (I225:950;131:2159)
                            width: 30*fem,
                            height: 42*fem,
                            child: Image.asset(
                              'assets/page-1/images/key-primary.png',
                              width: 30*fem,
                              height: 42*fem,
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyprimaryRqA (I225:950;131:2164)
                            width: 140*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyfunctionyLt (I225:950;131:2166)
                            width: 30*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffd9e2f8),
                              borderRadius: BorderRadius.circular(6*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  '.',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 22*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    color: Color(0xff1b1b1d),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 5*fem,
                          ),
                          Container(
                            // keyspecialfunctionTG4 (I225:950;131:2168)
                            width: 47*fem,
                            height: 42*fem,
                            child: Image.asset(
                              'assets/page-1/images/key-special-function.png',
                              width: 47*fem,
                              height: 42*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // homezFz (I225:950;131:2173)
                      padding: EdgeInsets.fromLTRB(146*fem, 8*fem, 145*fem, 8*fem),
                      width: double.infinity,
                      height: 20*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffeceff4),
                      ),
                      child: Center(
                        // homeKp4 (I225:950;131:2173;102:1037)
                        child: SizedBox(
                          width: double.infinity,
                          height: 4*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(8*fem),
                              color: Color(0xff1e1e1e),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // rectangle35GDW (225:1199)
              left: 0*fem,
              top: 129*fem,
              child: Align(
                child: SizedBox(
                  width: 375*fem,
                  height: 32*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // lowongankerjanBr (225:1200)
              left: 17.5*fem,
              top: 133*fem,
              child: Align(
                child: SizedBox(
                  width: 149*fem,
                  height: 25*fem,
                  child: Text(
                    'Lowongan kerja',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // magangH8c (225:1201)
              left: 236.5*fem,
              top: 133*fem,
              child: Align(
                child: SizedBox(
                  width: 77*fem,
                  height: 25*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Text(
                      'Magang',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 20*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2125*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line12a7i (225:1202)
              left: 8*fem,
              top: 165*fem,
              child: Align(
                child: SizedBox(
                  width: 161*fem,
                  height: 3*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff496454),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle5uQt (225:1203)
              left: 341*fem,
              top: 11*fem,
              child: Align(
                child: SizedBox(
                  width: 20*fem,
                  height: 9*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffd9d9d9),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle8S9v (225:1204)
              left: 362*fem,
              top: 14*fem,
              child: Align(
                child: SizedBox(
                  width: 1*fem,
                  height: 2*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffd9d9d9),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle6kRW (225:1205)
              left: 342*fem,
              top: 12*fem,
              child: Align(
                child: SizedBox(
                  width: 18*fem,
                  height: 7*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group20t1v (225:1206)
              left: 0*fem,
              top: 0*fem,
              child: Container(
                width: 375*fem,
                height: 136*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // rectangle131sE (225:1207)
                      left: 0*fem,
                      top: 0*fem,
                      child: Align(
                        child: SizedBox(
                          width: 375*fem,
                          height: 129*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              color: Color(0xff496454),
                              boxShadow: [
                                BoxShadow(
                                  color: Color(0x3f000000),
                                  offset: Offset(0*fem, 4*fem),
                                  blurRadius: 2*fem,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // textfieldsearchuxc (225:1208)
                      left: 17*fem,
                      top: 66*fem,
                      child: Container(
                        width: 264*fem,
                        height: 70*fem,
                        decoration: BoxDecoration (
                          borderRadius: BorderRadius.circular(8*fem),
                        ),
                        child: Container(
                          // autogrouprqbjEV6 (XVFDVbAxPTNAQiTQpXrQbJ)
                          width: double.infinity,
                          height: 50*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // bgAde (I225:1208;13:9701)
                                left: 0*fem,
                                top: 10*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 264*fem,
                                    height: 40*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(8*fem),
                                        color: Color(0x7fe0e0e0),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // textfield5Vi (I225:1208;13:9951)
                                left: 0*fem,
                                top: 10*fem,
                                child: Container(
                                  padding: EdgeInsets.fromLTRB(12*fem, 8*fem, 12*fem, 8*fem),
                                  width: 49*fem,
                                  height: 40*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(8*fem),
                                  ),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // captionn9E (I225:1208;13:9959)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                        child: Text(
                                          'PT',
                                          style: SafeGoogleFont (
                                            'IBM Plex Sans',
                                            fontSize: 16*ffem,
                                            fontWeight: FontWeight.w400,
                                            height: 1.5*ffem/fem,
                                            letterSpacing: 0.2687999916*fem,
                                            color: Color(0xff818181),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // carettegVW (I225:1208;13:10108)
                                        width: 3*fem,
                                        height: 24*fem,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(1*fem),
                                          color: Color(0xff1572ec),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Positioned(
                                // iconsrRhz (I225:1208;13:9715)
                                left: 228*fem,
                                top: 18*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 24*fem,
                                    height: 24*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/icons-r-asA.png',
                                      width: 24*fem,
                                      height: 24*fem,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // batalut4 (225:1209)
                      left: 311.5*fem,
                      top: 82*fem,
                      child: Align(
                        child: SizedBox(
                          width: 48*fem,
                          height: 25*fem,
                          child: Text(
                            'Batal',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Inter',
                              fontSize: 20*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.2125*ffem/fem,
                              color: Color(0xfffaf8ee),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}