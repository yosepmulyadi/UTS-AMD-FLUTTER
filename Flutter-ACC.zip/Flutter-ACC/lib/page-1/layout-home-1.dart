import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // layouthome1Gyn (220:210)
        width: double.infinity,
        height: 812*fem,
        decoration: BoxDecoration (
          color: Color(0xfffaf8ee),
        ),
        child: Stack(
          children: [
            Positioned(
              // group217PHi (220:225)
              left: 0*fem,
              top: 732*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(23*fem, 12*fem, 33*fem, 12*fem),
                width: 375*fem,
                height: 80*fem,
                decoration: BoxDecoration (
                  color: Color(0xfff3f4f9),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // autogroupqk5ifW8 (XVEss9ssmSZnqtN4saqK5i)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 38.5*fem, 0*fem),
                      width: 64*fem,
                      height: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupe3gcPBE (XVEsyz1q351mVjspaCe3Gc)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                            padding: EdgeInsets.fromLTRB(20*fem, 4*fem, 20*fem, 4*fem),
                            width: double.infinity,
                            decoration: BoxDecoration (
                              image: DecorationImage (
                                fit: BoxFit.cover,
                                image: AssetImage (
                                  'assets/page-1/images/active-indicator-BuJ.png',
                                ),
                              ),
                            ),
                            child: Center(
                              // iconUTa (220:229)
                              child: SizedBox(
                                width: 24*fem,
                                height: 24*fem,
                                child: Image.asset(
                                  'assets/page-1/images/icon-kME.png',
                                  width: 24*fem,
                                  height: 24*fem,
                                ),
                              ),
                            ),
                          ),
                          Text(
                            // labeltextyfE (220:230)
                            'Home',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.3333333333*ffem/fem,
                              letterSpacing: 0.5*fem,
                              color: Color(0xff001c38),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroupunjzGuE (XVEt4jNvDE5gKGkvCDUnjz)
                      margin: EdgeInsets.fromLTRB(0*fem, 6.55*fem, 46*fem, 0*fem),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // searchzqE (220:235)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 14.55*fem),
                            width: 18.9*fem,
                            height: 18.9*fem,
                            child: Image.asset(
                              'assets/page-1/images/search-x5W.png',
                              width: 18.9*fem,
                              height: 18.9*fem,
                            ),
                          ),
                          Text(
                            // labeltextVmz (220:232)
                            'Search',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.3333333333*ffem/fem,
                              letterSpacing: 0.5*fem,
                              color: Color(0xff001c38),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroupelfiEUg (XVEtA4ZNNbTNHhFoH3ELFi)
                      margin: EdgeInsets.fromLTRB(0*fem, 6*fem, 42.5*fem, 0*fem),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // infocircleZWx (220:231)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 14*fem),
                            width: 20*fem,
                            height: 20*fem,
                            child: Image.asset(
                              'assets/page-1/images/info-circle-CK2.png',
                              width: 20*fem,
                              height: 20*fem,
                            ),
                          ),
                          Text(
                            // labeltextGwA (220:233)
                            'Announ',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.3333333333*ffem/fem,
                              letterSpacing: 0.5*fem,
                              color: Color(0xff001c38),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroup55j61dr (XVEtEovTYkXH7E8tu455j6)
                      margin: EdgeInsets.fromLTRB(0*fem, 7*fem, 0*fem, 0*fem),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // settingsLRE (220:227)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0.51*fem, 13*fem),
                            width: 19.49*fem,
                            height: 20*fem,
                            child: Image.asset(
                              'assets/page-1/images/settings-ZUt.png',
                              width: 19.49*fem,
                              height: 20*fem,
                            ),
                          ),
                          Text(
                            // labeltextCyE (220:234)
                            'Setting',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Roboto',
                              fontSize: 12*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.3333333333*ffem/fem,
                              letterSpacing: 0.5*fem,
                              color: Color(0xff001c38),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // bYXJ (222:273)
              left: 0*fem,
              top: 139*fem,
              child: Container(
                width: 375*fem,
                height: 240*fem,
                decoration: BoxDecoration (
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x3f000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 2*fem,
                    ),
                  ],
                ),
                child: Container(
                  // gridcardtallqmJ (222:274)
                  width: double.infinity,
                  height: double.infinity,
                  decoration: BoxDecoration (
                    color: Color(0xffffffff),
                    borderRadius: BorderRadius.circular(4*fem),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x19000000),
                        offset: Offset(0*fem, 1*fem),
                        blurRadius: 4*fem,
                      ),
                      BoxShadow(
                        color: Color(0x1e000000),
                        offset: Offset(0*fem, 2*fem),
                        blurRadius: 2*fem,
                      ),
                      BoxShadow(
                        color: Color(0x28000000),
                        offset: Offset(0*fem, 1*fem),
                        blurRadius: 1*fem,
                      ),
                    ],
                  ),
                  child: Stack(
                    children: [
                      Positioned(
                        // imgi4Q (I222:274;394:769;0:401)
                        left: 0*fem,
                        top: 0*fem,
                        child: Align(
                          child: SizedBox(
                            width: 375*fem,
                            height: 168*fem,
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(4*fem),
                              child: Image.asset(
                                'assets/page-1/images/img.png',
                              ),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // overlayD1A (I222:274;394:779)
                        left: 0*fem,
                        top: 164*fem,
                        child: Align(
                          child: SizedBox(
                            width: 375*fem,
                            height: 76*fem,
                            child: Container(
                              decoration: BoxDecoration (
                                color: Color(0xffffffff),
                                borderRadius: BorderRadius.only (
                                  bottomRight: Radius.circular(4*fem),
                                  bottomLeft: Radius.circular(4*fem),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        // title6ak (I222:274;394:771)
                        left: 16*fem,
                        top: 164*fem,
                        child: Align(
                          child: SizedBox(
                            width: 307*fem,
                            height: 56*fem,
                            child: Text(
                              'Support system, programmer,it Support',
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 20*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.4*ffem/fem,
                                letterSpacing: 0.150000006*fem,
                                color: Color(0xff263238),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              // autogroupbyslLV6 (XVEsVVqHz8cJaYbEr7bYSL)
              left: 0*fem,
              top: 380*fem,
              child: Container(
                width: 375*fem,
                height: 50*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0x3f000000),
                      offset: Offset(0*fem, 4*fem),
                      blurRadius: 2*fem,
                    ),
                  ],
                ),
                child: Center(
                  child: Text(
                    'Download',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w700,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff496454),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // autogroupqsucwzg (XVEscF93yJSbdzAAdBqsUc)
              left: 0*fem,
              top: 431*fem,
              child: Container(
                width: 375*fem,
                height: 50*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                ),
                child: Center(
                  child: Text(
                    'Lihat Detail',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w700,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff496454),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle13bZS (220:236)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 375*fem,
                  height: 129*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff496454),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // yosepmulyadigKz (220:237)
              left: 64*fem,
              top: 77*fem,
              child: Align(
                child: SizedBox(
                  width: 83*fem,
                  height: 15*fem,
                  child: Text(
                    'Yosep Mulyadi',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 12*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // universitasipendidikanindonesi (220:238)
              left: 63*fem,
              top: 99*fem,
              child: Align(
                child: SizedBox(
                  width: 159*fem,
                  height: 13*fem,
                  child: Text(
                    'Universitasi Pendidikan Indonesia',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 10*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line5pKi (220:239)
              left: 64*fem,
              top: 96*fem,
              child: Align(
                child: SizedBox(
                  width: 155*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // group21urx (220:240)
              left: 327*fem,
              top: 80*fem,
              child: Align(
                child: SizedBox(
                  width: 30*fem,
                  height: 30*fem,
                  child: Image.asset(
                    'assets/page-1/images/group-21-D7W.png',
                    width: 30*fem,
                    height: 30*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // bellS6C (220:242)
              left: 333*fem,
              top: 87*fem,
              child: Align(
                child: SizedBox(
                  width: 18*fem,
                  height: 18*fem,
                  child: Image.asset(
                    'assets/page-1/images/bell-352.png',
                    width: 18*fem,
                    height: 18*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // ellipse10Yuv (220:243)
              left: 7*fem,
              top: 69*fem,
              child: Align(
                child: SizedBox(
                  width: 49*fem,
                  height: 49*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(24.5*fem),
                      color: Color(0xfffaf8ee),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // notifremovebgpreview2rvc (220:244)
              left: 324*fem,
              top: 79*fem,
              child: Align(
                child: SizedBox(
                  width: 35*fem,
                  height: 31*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Container(
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // avaremovebgpreview1AwJ (220:245)
              left: 9*fem,
              top: 71*fem,
              child: Align(
                child: SizedBox(
                  width: 45*fem,
                  height: 45*fem,
                  child: Image.asset(
                    'assets/page-1/images/ava-removebg-preview-1.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}