import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // layoutsigninRyi (53:2)
        width: double.infinity,
        height: 812*fem,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
          image: DecorationImage (
            fit: BoxFit.cover,
            image: AssetImage (
              'assets/page-1/images/layout-awal-1-bg-NnU.png',
            ),
          ),
        ),
        child: Stack(
          children: [
            Positioned(
              // rectangle10sck (191:277)
              left: 0*fem,
              top: 752*fem,
              child: Align(
                child: SizedBox(
                  width: 375*fem,
                  height: 60*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xb2ffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle11YTz (191:278)
              left: 0*fem,
              top: 761*fem,
              child: Align(
                child: SizedBox(
                  width: 188*fem,
                  height: 51*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff496454),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle12qhz (191:279)
              left: 195*fem,
              top: 761*fem,
              child: Align(
                child: SizedBox(
                  width: 180*fem,
                  height: 51*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff496454),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // joinnowYMW (191:280)
              left: 27*fem,
              top: 773*fem,
              child: Align(
                child: SizedBox(
                  width: 129*fem,
                  height: 31*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Text(
                      'JOIN NOW',
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 25*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.2125*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // signinkTa (191:281)
              left: 239*fem,
              top: 773*fem,
              child: Align(
                child: SizedBox(
                  width: 92*fem,
                  height: 31*fem,
                  child: Text(
                    'SIGN IN',
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 25*ffem,
                      fontWeight: FontWeight.w700,
                      height: 1.2125*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle9ENk (53:22)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 375*fem,
                  height: 812*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0x7f496454),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // rectangle13Xse (53:21)
              left: 39*fem,
              top: 144*fem,
              child: Align(
                child: SizedBox(
                  width: 302*fem,
                  height: 430*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(10*fem),
                      color: Color(0xffffffff),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // signinxi4 (53:23)
              left: 60.5*fem,
              top: 184*fem,
              child: Align(
                child: SizedBox(
                  width: 97*fem,
                  height: 37*fem,
                  child: Text(
                    'Sign In',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 30*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // emailqWx (53:24)
              left: 62*fem,
              top: 264*fem,
              child: Align(
                child: SizedBox(
                  width: 51*fem,
                  height: 25*fem,
                  child: Text(
                    'Email',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff605656),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // passwordvoJ (53:25)
              left: 62.5*fem,
              top: 351*fem,
              child: Align(
                child: SizedBox(
                  width: 93*fem,
                  height: 25*fem,
                  child: Text(
                    'Password',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff605656),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // forgetpasswordyma (53:26)
              left: 63.5*fem,
              top: 446*fem,
              child: Align(
                child: SizedBox(
                  width: 244*fem,
                  height: 28*fem,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Text(
                      'FORGET PASSWORD ?',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 23*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.2125*ffem/fem,
                        color: Color(0xff605656),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line23WY (53:27)
              left: 64*fem,
              top: 329*fem,
              child: Align(
                child: SizedBox(
                  width: 248*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // line3jeG (53:28)
              left: 64*fem,
              top: 415*fem,
              child: Align(
                child: SizedBox(
                  width: 248*fem,
                  height: 1*fem,
                  child: Container(
                    decoration: BoxDecoration (
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // fabqSQ (190:241)
              left: 122*fem,
              top: 510*fem,
              child: Container(
                width: 92*fem,
                height: 40*fem,
                decoration: BoxDecoration (
                  color: Color(0xff2f4156),
                  borderRadius: BorderRadius.circular(100*fem),
                ),
                child: Center(
                  child: Center(
                    child: Text(
                      'Cancel',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.4285714286*ffem/fem,
                        letterSpacing: 0.1000000015*fem,
                        color: Color(0xffd7e2ff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // fabfwE (190:243)
              left: 231*fem,
              top: 510*fem,
              child: Container(
                width: 92*fem,
                height: 40*fem,
                decoration: BoxDecoration (
                  color: Color(0xff2f4156),
                  borderRadius: BorderRadius.circular(100*fem),
                ),
                child: Center(
                  child: Center(
                    child: Text(
                      'Sign in',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.4285714286*ffem/fem,
                        letterSpacing: 0.1000000015*fem,
                        color: Color(0xffd7e2ff),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // viewXiY (197:298)
              left: 281.1422119141*fem,
              top: 391.75*fem,
              child: Align(
                child: SizedBox(
                  width: 24.85*fem,
                  height: 15.5*fem,
                  child: Image.asset(
                    'assets/page-1/images/view.png',
                    width: 24.85*fem,
                    height: 15.5*fem,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}