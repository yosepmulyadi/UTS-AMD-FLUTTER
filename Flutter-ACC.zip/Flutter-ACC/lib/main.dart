import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'package:myapp/page-1/layout-sign-in.dart';
// import 'package:myapp/page-1/layout-sign-in-load.dart';
// import 'package:myapp/page-1/layout-forget-pass.dart';
// import 'package:myapp/page-1/layout-forget-pass-load.dart';
// import 'package:myapp/page-1/layout-landing-page.dart';
// import 'package:myapp/page-1/layout-konfirmasi.dart';
// import 'package:myapp/page-1/layout-opsi-in.dart';
// import 'package:myapp/page-1/layout-load.dart';
// import 'package:myapp/page-1/layout-join-now.dart';
// import 'package:myapp/page-1/layout-notifikasi.dart';
// import 'package:myapp/page-1/layout-in-notifikasi.dart';
// import 'package:myapp/page-1/layout-home.dart';
// import 'package:myapp/page-1/layout-home-1.dart';
// import 'package:myapp/page-1/layout-home1-klik.dart';
// import 'package:myapp/page-1/layout-home2-klik.dart';
// import 'package:myapp/page-1/layout-home-2.dart';
// import 'package:myapp/page-1/layout-pengaturan.dart';
// import 'package:myapp/page-1/layout-info-pengumuman.dart';
// import 'package:myapp/page-1/layout-info-agenda.dart';
// import 'package:myapp/page-1/layout-info-berita.dart';
// import 'package:myapp/page-1/layout-pencarian-loker.dart';
// import 'package:myapp/page-1/layout-pencarian-loker-key.dart';
// import 'package:myapp/page-1/layout-pencarian-magang-key.dart';
// import 'package:myapp/page-1/layout-pencarian-magang.dart';
// import 'package:myapp/page-1/layout-profil.dart';
// import 'package:myapp/page-1/layout-keamanan.dart';
// import 'package:myapp/page-1/layout-pengaturan-umum.dart';
// import 'package:myapp/page-1/layout-masukan.dart';
// import 'package:myapp/page-1/layout-pusat-bantuan.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
	@override
	Widget build(BuildContext context) {
	return MaterialApp(
		title: 'Flutter',
		debugShowCheckedModeBanner: false,
		scrollBehavior: MyCustomScrollBehavior(),
		theme: ThemeData(
		primarySwatch: Colors.blue,
		),
		home: Scaffold(
		body: SingleChildScrollView(
			child: Scene(),
		),
		),
	);
	}
}
